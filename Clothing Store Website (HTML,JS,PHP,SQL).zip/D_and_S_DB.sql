-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 14 Σεπ 2024 στις 20:18:44
-- Έκδοση διακομιστή: 10.4.32-MariaDB
-- Έκδοση PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `d_and_s`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `cart`
--

CREATE TABLE `cart` (
  `cartId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `comments`
--

CREATE TABLE `comments` (
  `commentId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `comments`
--

INSERT INTO `comments` (`commentId`, `userId`, `comment`, `createdAt`) VALUES
(1, 6, 'Very good quality!', '2024-09-07 17:20:51'),
(3, 6, 'Would recommend <3', '2024-09-14 17:02:16');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `products`
--

CREATE TABLE `products` (
  `productId` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `productImage` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `availability` int(11) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `products`
--

INSERT INTO `products` (`productId`, `title`, `productImage`, `price`, `availability`, `category`) VALUES
(1, 'Grey Sweatpants with Pink Stripes ', 'clothingImages/pants1.JPG', 20.00, 17, 'pants'),
(2, 'Classic High-Quality Denim Jeans', 'clothingImages/pants2.jpg', 35.00, 20, 'pants'),
(3, 'Elegant Asymmetric White Corset', 'clothingImages/top3.JPG', 22.00, 19, 'tops'),
(4, 'Casual Gray and Burgundy Top', 'clothingImages/top5.JPG', 14.00, 25, 'tops'),
(7, 'Dark Wash High Waisted Jeans', 'clothingImages/pants3.JPG', 25.00, 45, 'pants'),
(8, 'Olive Green Cargo Shorts', 'clothingImages/shorts1.JPG', 17.00, 60, 'pants'),
(9, 'Black Tee with Pink Flower Cutout', 'clothingImages/top7.JPG', 15.00, 50, 'tops'),
(10, 'Orange Floral Print Top', 'clothingImages/top1.JPG', 11.00, 60, 'tops'),
(11, 'Colorful Asymmetrical Dress ', 'clothingImages/dress3.JPG', 27.00, 46, 'dresses'),
(12, 'White Short Preppy Dress', 'clothingImages/dress4.JPG', 30.00, 40, 'dresses'),
(13, 'Blue Satin Floor Length Dress', 'clothingImages/dress2.JPG', 43.00, 44, 'dresses'),
(14, 'Lilac Floor Length Dress', 'clothingImages/dress5.JPG', 45.00, 55, 'dresses'),
(15, 'Casual Black and White windbreaker', 'clothingImages/jacket1.JPG', 30.00, 22, 'Jackets'),
(16, 'Casual Black and Gray Windbreaker', 'clothingImages/jacket2.JPG', 28.00, 40, 'Jackets'),
(17, 'Dark Blue Zip Up Hoodie', 'clothingImages/jacket3.JPG', 23.00, 23, 'Jackets'),
(18, 'Black Denim Mini Skirt', 'clothingImages/skirt1.JPG', 16.00, 12, 'Skirts'),
(19, 'Light Wash Denim Skirt', 'clothingImages/skirt2.JPG', 12.00, 12, 'Skirts');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `purchases`
--

CREATE TABLE `purchases` (
  `purchaseId` int(11) NOT NULL,
  `userPurchaseId` int(11) NOT NULL,
  `productPurchaseId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchaseDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `purchases`
--

INSERT INTO `purchases` (`purchaseId`, `userPurchaseId`, `productPurchaseId`, `quantity`, `purchaseDate`) VALUES
(1, 6, 7, 1, '2024-09-07 15:12:12'),
(2, 6, 14, 1, '2024-09-07 15:12:50'),
(3, 6, 8, 1, '2024-09-07 15:12:50'),
(4, 6, 8, 1, '2024-09-07 15:15:35'),
(5, 6, 16, 1, '2024-09-14 16:49:59'),
(6, 6, 1, 1, '2024-09-14 16:49:59');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `userPassword` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `users`
--

INSERT INTO `users` (`userId`, `firstName`, `lastName`, `username`, `userPassword`, `email`, `address`) VALUES
(1, 'Alexandra', 'Bouzi', 'alexb', 'alex123', 'buzialexandra@gmail.com', 'xx 22'),
(2, 'Joanna', 'Bouzi', 'joannab', '$2y$10$ytVKteU39evzUGkL/QaFk.Oj69.Ye7wWjnd4I6NKHb9.rJd6/aWki', 'buzijoanna@gmail.com', 'and 23'),
(3, 'Mary', 'Bright', 'maryb', '$2y$10$BEyXPunKfhuDR8skJrbToOi7pvBzL/idrj2jx/6yNdX7kXH5Dyj7a', 'marybright@gmail.com', 'street 34\r\n'),
(4, 'abx', 'xbdf', 'trial', '$2y$10$eHbqef6bOin2Az67lgCwiOXLcV0kBX7iiVtNnH6aLfq8T.h4iKOh2', 'fklsfkl@gmail.com', 'fvkdfjk 33'),
(5, 'Nicky', 'Bern', 'nickyb', '$2y$10$wymZHiR3OHfV2YHYrgk1OemI1sQIk.WMmD0OLY3OWjkDnMDQUP95S', 'nicky@gmail.com', 'street 374'),
(6, 'AlexandraMaria', 'Buzi', 'alexabouzi', '$2y$10$RrmU.6yiITF7oEUXoHBrE.pC7lMDCJxi7I.78UiRN6rw5sVVMG8b2', 'alex123@gmail.com', 'alexas 34');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartId`),
  ADD UNIQUE KEY `uniqueUserOrder` (`userId`,`productId`),
  ADD KEY `productId` (`productId`);

--
-- Ευρετήρια για πίνακα `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentId`),
  ADD KEY `userId` (`userId`);

--
-- Ευρετήρια για πίνακα `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productId`);

--
-- Ευρετήρια για πίνακα `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`purchaseId`),
  ADD KEY `userPurchaseId` (`userPurchaseId`),
  ADD KEY `productPurchaseId` (`productPurchaseId`);

--
-- Ευρετήρια για πίνακα `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `cart`
--
ALTER TABLE `cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT για πίνακα `comments`
--
ALTER TABLE `comments`
  MODIFY `commentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT για πίνακα `products`
--
ALTER TABLE `products`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT για πίνακα `purchases`
--
ALTER TABLE `purchases`
  MODIFY `purchaseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT για πίνακα `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`userId`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`productId`);

--
-- Περιορισμοί για πίνακα `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`userId`);

--
-- Περιορισμοί για πίνακα `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`userPurchaseId`) REFERENCES `users` (`userId`),
  ADD CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`productPurchaseId`) REFERENCES `products` (`productId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
