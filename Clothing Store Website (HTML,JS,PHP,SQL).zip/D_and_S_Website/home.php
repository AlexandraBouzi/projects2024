    <?php
    include 'database.php'; //include database file
    session_start();
    $loggedIn = isset($_SESSION['userId']); //check if user is logged in (using userId $_SESSION)
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addToCart'])) { //check whether the addToCart is set
    if (!$loggedIn) { //if user isn't logged in..
        header("Location: login_register.php");//redirect them on the login/register page
        exit;//stopping the further execution
    }
    //getting product ids and user id
    $productId = $_POST['productId'];
    $userId = $_SESSION['userId'];
    // SQL query to check if the product already exists in the user's cart
    $sql = "SELECT * FROM cart WHERE userId = ? AND productId = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $productId); //binding the params userId and productId
    $stmt->execute();
    $result = $stmt->get_result();

    //if the product already exists in the cart..
    if ($result->num_rows > 0) { 
        $sql = "UPDATE cart SET quantity = quantity + 1 WHERE userId = ? AND productId = ?"; //SQL query that adds into the quantity
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $userId, $productId);
    } else {
    //if the product does not exist yet using the adequate SQL query..
        $sql = "INSERT INTO cart (userId, productId, quantity) VALUES (?, ?, 1)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $userId, $productId);
    }
    $stmt->execute();
}

$sql = "SELECT * FROM products"; //SQL query to show all the existing products
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <!--link for the emojis used-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--css styling for the whole home.php-->
    <style>
        html{
                height: 100%;
                display: flex; /*affects header*/
                flex-direction: column; /*centre everything*/
                align-items: center;
                font-family: Helvetica, Verdana, Arial;
            }

        body{
                background-image: url("homeBackground.png");
                background-size: cover;
                background-attachment: fixed;
            }


        .header{
                font-family: 'Cursive', Arial;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 15px;
                padding: 15px;
                background-color: rgba(255, 237, 205, 0.9);
                border-radius: 10px;
                width: 100%;
                 box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }

        .webTitle {
                background-color: rgba(255, 237, 205, 0.9);
                padding: 8px;
                text-align: center;
                color: rgb(28, 47, 111);
                border-radius: 10px;
                margin-bottom: 10px;
                flex: 1;
                }

        .navigation {
                display: flex;
                justify-content: center;
                align-items: center;
                background-color: rgb(242, 168, 179); /*pink*/
                padding: 10px;
                width: 100%;
                border-radius: 10px;
                text-align: center;
                }       

        .navigation i {
            position: relative;
            color: rgb(28, 47, 111);
            padding: 10px 15px;
            font-size: 1.2em;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .navigation a {
            text-decoration: none;
            color: inherit;
        }
        /*for hovering on navigation options*/
        .navigation i:hover {
            background-color: rgb(247, 196, 213);
            color: rgb(31, 136, 201);
            border-radius: 7px;
        }
        /*changing the color of the page that is active*/
        .navigation i.active {
            background-color: rgb(33, 55, 129);
            color: rgb(247, 196, 213);
            border-radius: 7px;
        }

        .mainContent {
            font-family: 'Cursive', Arial;
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url("homeBackground.png");
            background-size: cover; /*make background-photo fit well in the screen*/
            background-attachment: fixed;
        }

  

        /* appearence of category title */
        .categoryHeader {
            font-size: 1.8em;
            color:  rgb(242, 168, 179) ;
            margin:auto;
            text-align: center;
            font-family: Cursive, Arial;
            background-color: rgba(255,237,205,0.9);
            border-radius :10px;
            width:130px;
            padding:10px;
        }

        .categoryGroup {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .categoryContainer {
            margin-bottom: 20px;
        }


        .products {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            justify-content: center; /* align the product cards */
            margin: 0 auto;
            max-width: 1200px; /* max width for the product grid */
            width: 100%;
        }

        .product {
            background-color: rgba(255, 237, 205, 0.9);
            border-radius: 10px;
            flex: 1 1 250px; /*flexible base size of 250px for each product */
            max-width: 250px; 
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        .product img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .product form {
            display: flex;
            flex-direction: column;
            align-items: center; /* Centers form elements */
            gap: 10px;
        }

        /* Media query for smaller screens */
        @media (max-width: 768px) {
            .products {
                justify-content: center;
            }
            .product {
                flex: 1 1 45%; /* 2 products when the screen size decreases */
                max-width: 100%; /*for overflow */
            }
        }

        

        .product h2 {
            font-size: 1.3em;
            color: rgb(28, 47, 111);
            margin: 10px 0;
            font-family: 'Cursive', arial;
        }

        .product p {
            font-size: 1.3em;
            color: rgb(28, 47, 111);
            margin: 12px 0;
            font-family: 'Cursive', arial; 
        }


        .product input[type="number"] {
            width: 60px;
            padding: 5px;
            font-size: 1em;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .product button {
            font-family:'Cursive',arial; 
            background-color: rgb(242, 168, 179);
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }

        .product button:hover {
            background-color: rgb(247, 196, 213);
        }
        .numOfProductsChosen {
            width: 70px;
            padding: 5px;
            font-size: 1em;
            font-family: 'Cursive', Arial; 
            color: rgb(28, 47, 111); 
            border: 2px solid rgb(242, 168, 179); 
            border-radius: 5px; 
            background-color:rgba(255,237,205,0.9); 
            text-align: center; 
        }

        /*when input is focused */
        .numOfProductsChosen:focus {
            border-color: rgb(247, 196, 213); 
            box-shadow: 0 0 5px rgba(247, 196, 213, 0.8); 
        }

        footer {
            background-color: rgba(255, 237, 205, 255);
            border-radius: 10px;
            padding: 10px;
            font-family: Cursive, Arial;
            text-align: center;
            width: 100%;
            margin-top: auto; 
        }

        .footerContainer {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }

        .contactInfo {
            background-color: rgba(255, 237, 205, 255);
            width: 100%;
            max-width: 500px;
            border-radius: 10px;
            padding: 10px;
            color: rgb(238, 151, 164);
            box-sizing: border-box;
        }
        .map {
            background-color: rgba(255, 237, 205, 255);
            width: 100%;
            max-width: 500px;
            border-radius: 10px;
            padding: 10px;
            color: rgb(238, 151, 164);
            box-sizing: border-box;
        }


        .contactInfo p, .map h3 {
            margin: 5px 0;
        }

        iframe {
            width: 100%;
            height: 200px;
            border: 0;
            border-radius: 10px;
        }

        a:link {
            color: rgb(28, 47, 111);
        }

        a:hover {
            color: rgba(255, 237, 205, 255);
            background-color: rgb(238, 151, 164);
            padding: 5px;
            border-radius: 10px;
        }


        @media (max-width: 768px) {
            .footerContainer {
                flex-direction: column;
                gap: 10px;
            }

            .contactInfo, .map {
                max-width: 100%;
            }

            iframe {
                height: 300px; 
            }
        }
</style>
</head>
<body>
    <div class="header">
        <title>WhimsyWear Clothing</title>
        <h1 class="webTitle"><span class="fa-solid fa-vest-patches"></span> WhimsyWear</h1>
        <div class="navigation">
        <a href="cart.php"><i class="fa-solid fa-basket-shopping"> MY CART</i></a>
            <a href="home.php"><i class="fa-solid fa-house active">HOME</i> </a>
            <a href="rate.php"><i class="fa-solid fa-star">RATE US</i>  </a>
            <?php if ($loggedIn): ?>  
                <a href="logout.php"><i class="fa-solid fa-right-from-bracket">LOG OUT</i></a>
            <?php else: ?>
                <a href="loginRegister.php" class="active"><i class="fa-solid fa-user"> LOGIN / REGISTER</i > </a>
            <?php endif; ?>
        </div>
    </div> 


    <main class="mainContent">
        <div class="products">
            <?php
            //Database connection
            $conn = new mysqli('localhost', 'root', '', 'd_and_s');
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            //Retrieve products from the database
            $sql = "SELECT * FROM products ORDER BY category ASC";
            $result = $conn->query($sql);

            //Display products grouped by set categories
            $currentCategory = '';
            while($row = $result->fetch_assoc()):
                if ($row['category'] != $currentCategory):
                    if ($currentCategory != ''): ?>
                        </div> 
                    <?php endif;
                    $currentCategory = $row['category']; ?>
                    <div class="categoryContainer" dataCategory="<?php echo htmlspecialchars($currentCategory); ?>">
                        <h2 class="categoryHeader"><?php echo ucfirst(htmlspecialchars($currentCategory)); ?></h2>
                        <div class="categoryGroup">
                    <?php endif; ?>

                    <div class="product" dataCategory="<?php echo htmlspecialchars($row['category']); ?>">
                    <img src="<?php echo htmlspecialchars($row['productImage']); ?>" alt="<?php echo htmlspecialchars($row['title']); ?>">
                    <h2><?php echo htmlspecialchars($row['title']); ?></h2>
                    <p>Price: <?php echo htmlspecialchars($row['price']); ?>€</p>
                    <form method="POST" action="addToCart.php">
                        <input type="hidden" name="productId" value="<?php echo htmlspecialchars($row['productId']); ?>">
                        <input type="number" name="quantity" class="numOfProductsChosen" value="1" min="1" max="<?php echo htmlspecialchars($row['availability']); ?>">
                        <button type="submit" name="addToCart">Add to Cart</button>
                    </form>
                </div>

                <?php endwhile;
                if ($currentCategory != ''): ?>
                    </div> 
                <?php endif;
                $conn->close();
                ?>
            </div>
    </main>


    <footer>
        <div class="footerContainer">
            <div class="contactInfo">
                <p><strong>WhimsyWear Clothing</strong></p>
                <p><a href="tel:+1234567890">+123 456 7890</a></p>
                <p><a href="mailto:buzialexandra@gmail.com">buzialexandra@gmail.com</a></p>
                <p>Androutsou 150, Piraeus, Greece</p>
            </div>
            <div class="map">
                <h3>Our Location</h3>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3133.2880325410413!2d23.643801615677364!3d37.94318797972616!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1bcf7b064ed27%3A0x82bf2b8d795fd2!2sAndroutsou%20150%2C%20Pireas%20185%2034%2C%20Greece!5e0!3m2!1sen!2sus!4v1625573188392!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </footer>
</body>
</html>