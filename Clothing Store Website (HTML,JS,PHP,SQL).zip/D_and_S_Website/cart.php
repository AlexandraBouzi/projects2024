<?php
include 'database.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userId'])) {
    // If not logged in, redirect to login page
    header("Location: loginRegister.php");
    exit();
}

// Retrieve user information from the database
$userId = $_SESSION['userId'];
$sql = "SELECT * FROM users WHERE userId = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$userResult = $stmt->get_result();
$user = $userResult->fetch_assoc();

// Initialize variables
$cartItems = []; // Store cart items
$initialPaymentAmount = 0; // Initial total price
$discountPercentage = rand(10, 30) / 100; // Random discount percentage between 10% and 30%

// Retrieve the user's cart items and product prices
$cartSql = "
    SELECT c.cartId, p.productId, p.title, p.price, c.quantity
    FROM cart c
    JOIN products p ON c.productId = p.productId
    WHERE c.userId = ?
";
$cartStmt = $conn->prepare($cartSql);
$cartStmt->bind_param("i", $userId);
$cartStmt->execute();
$cartResult = $cartStmt->get_result();

while ($row = $cartResult->fetch_assoc()) {
    $cartItems[] = $row;
    $initialPaymentAmount += $row['price'] * $row['quantity']; // Sum up the initial payment amount considering quantity
}

// Calculate final payment amount
$finalPaymentAmount = $initialPaymentAmount - ($initialPaymentAmount * $discountPercentage);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['removeItemId'])) {
        // Remove item from cart
        $removeItemId = $_POST['removeItemId'];
        $deleteSql = "DELETE FROM cart WHERE cartId = ? AND userId = ?";
        $deleteStmt = $conn->prepare($deleteSql);
        $deleteStmt->bind_param("ii", $removeItemId, $userId);
        $deleteStmt->execute();

        // Redirect to refresh the cart
        header("Location: cart.php");
        exit();
    } elseif (isset($_POST['updateUserDetails'])) {
        // Update user details
        $updatedFirstName = $_POST['firstName'];
        $updatedLastName = $_POST['lastName'];
        $updatedEmail = $_POST['email'];
        $updatedAddress = $_POST['address'];

        $updateSql = "UPDATE users SET firstName = ?, lastName = ?, email = ?, address = ? WHERE userId = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("ssssi", $updatedFirstName, $updatedLastName, $updatedEmail, $updatedAddress, $userId);
        $updateStmt->execute();

        // Display success message
        echo "<p class='success-message'>Details updated successfully.</p>";
    } elseif (isset($_POST['placeOrder'])) {
        // Handle order placement
        $conn->begin_transaction(); // Start a transaction to ensure all or nothing execution

        try {
            // Insert each cart item as a purchase
            foreach ($cartItems as $item) {
                $insertPurchaseSql = "INSERT INTO purchases (userPurchaseId, productPurchaseId, quantity, purchaseDate) VALUES (?, ?, ?, NOW())";
                $insertPurchaseStmt = $conn->prepare($insertPurchaseSql);
                $insertPurchaseStmt->bind_param("iii", $userId, $item['productId'], $item['quantity']);
                $insertPurchaseStmt->execute();
            }

            // Clear the cart after placing the order
            $clearCartSql = "DELETE FROM cart WHERE userId = ?";
            $clearCartStmt = $conn->prepare($clearCartSql);
            $clearCartStmt->bind_param("i", $userId);
            $clearCartStmt->execute();

            // Commit the transaction
            $conn->commit();

          // Display success message and redirect to home
          echo "<script>
          alert('Order placed successfully! Redirecting to home page...');
          window.location.href = 'home.php';
      </script>";
      exit();
  } catch (Exception $e) {
      // Rollback the transaction if any error occurs
      $conn->rollback();
      echo "<script>
          alert('There was an error placing your order. Please try again.');
          window.location.href = 'cart.php';
      </script>";
      exit();
  }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
        <title>My Cart - WhimsyWear</title>
        <style>
                body {
                    background-image: url("homeBackground.png");
                    background-size: cover;
                    }

                .header {
                    font-family: 'Cursive', Arial;
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                    padding: 15px;
                    background-color: rgba(255, 237, 205, 0.9);
                    border-radius: 10px;
                    width: 69.5%;
                    position:relative;
                    left:14%;
                
                }

                .webTitle {
                    background-color: rgba(255, 237, 205, 0.9);
                    padding: 8px;
                    text-align: center;
                    color: rgb(28, 47, 111);
                    border-radius: 10px;
                    margin-bottom: 10px;
                    flex: 1;
                }

                
                .navigation {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    background-color: rgb(242, 168, 179); /*pink*/
                    padding: 10px;
                    width: 100%;
                    border-radius: 10px;
                    text-align: center;
                }

                .navigation i {
                    position: relative;
                    color: rgb(28, 47, 111);
                    padding: 10px 15px;
                    font-size: 1.2em;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 5px;
                }

                .navigation a {
                    text-decoration: none;
                    color: inherit;
                }

                .navigation i:hover {
                    background-color: rgb(247, 196, 213);
                    color: rgb(31, 136, 201);
                    border-radius: 7px;
                }

                .navigation i.active {
                    background-color: rgb(33, 55, 129);
                    color: rgb(247, 196, 213);
                    border-radius: 7px;
                }


                main{
                    background-color: rgba(255, 237, 205, 0.9);
                    opacity:0.9;
                    width:68%;
                    padding: 40px;
                    text-align:center;
                    margin:auto;
                }
                h1,h2{
                    font-family: Cursive,arial;
                    color: rgb(28, 47, 111);
                    
                }
                table{
                    margin-left: auto;
                    margin-right: auto;
                    margin-bottom:70px;
                }

                th{
                    font-family: Cursive,arial;
                    color:rgb(28, 47, 111);
                    margin-left:20px;
                    border: 35px solid transparent;
                    text-decoration: underline pink;
                }
                tr,p{
                    font-family: Cursive,arial;
                    color:rgb(28, 47, 111);
                
                }

                .totalPaymentInfo{
                    font-size:18px;
                    margin:25px;
                }

                .finalAmount{
                    font-size:20px;
                    font-weight:bold;
                    color:#eb7094;
                }
                .informationContainer{
                    margin:70px;
                }

                .clientInfo{font-family: Cursive,arial;
                    color:rgb(28, 47, 111);
                    font-size:17px;
                    display: flex;
                    justify-content: space-between;
                    flex-direction: column;
                    margin:10px;
                }

                .clientResponse{
                font-family: Cursive,arial;

                height:40px; 
                width: 200px; 
                border-radius: 4px 4px 4px 4px;
                box-sizing: border-box;
                font-size: 16px;
                color: rgb(28, 47, 111);
                background-color: rgba(255, 237, 205, 0.9);
                box-shadow: 0px 0px 0px 1px rgb(28, 47, 111);

                }

                .updateButton{
                    font-family: Cursive,arial;
                    display: flex;
                    justify-content: center;
                    flex-direction: column;
                    margin:0 auto;
                    background-color: pink;
                    color:rgb(28, 47, 111);
                    border-radius: 30px;
                    padding:10px 15px 10px 15px;
                    border:1px pink;
                    
                }
                .removeButton{
                    font-family: Cursive,arial;
                    background-color: pink;
                    color:rgb(28, 47, 111);
                    border-radius: 4px 4px 4px 4px;
                    border-radius: 30px;
                    padding:10px 15px 10px 15px;
                    border:2px pink;
                }
                .orderButton{
                    font-family: Cursive,arial;
                    background-color:#ed81a1;
                
                    color:rgb(28, 47, 111);
                    border-radius: 7px 7px 7px 7px;
                    border-radius: 40px;
                    padding: 20px;
                    border:2px pink;
                    font-weight:bold;
                    font-size:20px;
                    margin:30px;
                }
                .removeButton:hover, .updateButton:hover,.orderButton:hover{
                    background-color: rgb(28, 47, 111);
                    color: rgba(255, 237, 205, 0.9);
                    border-radius: 5px;
                }
                .mostImportantInfo{
                    background-color:rgb(255, 208, 215);
                    opacity:1;
                    width:2 auto;
                    border-radius: 50px;
                    width:400px;
                    margin-left:auto;
                    margin-right:auto;
                
                }

                footer {
                    background-color: rgba(255, 237, 205, 255);
                    border-radius: 10px;
                    padding: 10px;
                    font-family: Cursive, Arial;
                    text-align: center;
                    width: 70%;
                    
                    margin-top:10px auto; 
                    margin:0 auto;
                }

                /* Footer Container Styling */
                .footerContainer {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    gap: 20px;
                
                }

                /* Contact Info and Map Styling */
                .contactInfo {
                    background-color: rgba(255, 237, 205, 255);
                    width: 100%;
                    max-width: 500px;
                    border-radius: 10px;
                    padding: 10px;
                    color: rgb(238, 151, 164);
                    box-sizing: border-box;
                }
                .map {
                    background-color: rgba(255, 237, 205, 255);
                    width: 100%;
                    max-width: 500px;
                    border-radius: 10px;
                    padding: 10px;
                    color: rgb(238, 151, 164);
                    box-sizing: border-box;
                }


                .contactInfo p, .map h3 {
                    margin: 5px 0;
                }

                iframe {
                    width: 100%;
                    height: 200px;
                    border: 0;
                    border-radius: 10px;
                }


                a:link {
                    color: rgb(28, 47, 111);
                }

                a:hover {
                    color: rgba(255, 237, 205, 255);
                    background-color: rgb(238, 151, 164);
                    padding: 5px;
                    border-radius: 10px;
                }

                /* Responsive Styling */
                @media (max-width: 768px) {
                    .footerContainer {
                        flex-direction: column;
                        gap: 10px;
                    }

                    .contactInfo, .map {
                        max-width: 100%;
                    }

                    iframe {
                        height: 300px; 
                    }
                }




        </style>
    </head>
    <body>

<div class="header">
        <title>WhimsyWear Clothing</title>
        <h1 class="webTitle"><span class="fa-solid fa-vest-patches"></span> WhimsyWear</h1>
        <div class="navigation">
        <a href="cart.php"><i class="fa-solid fa-basket-shopping active"> MY CART</i></a>
            <a href="home.php"><i class="fa-solid fa-house">HOME</i> </a>
            <a href="rate.php"><i class="fa-solid fa-star">RATE US</i>  </a>
            <a href="logout.php"><i class="fa-solid fa-right-from-bracket">LOG OUT</i></a>
        </div>
</div> 

<main>
    <div class="cartContainer">
    <h1>My Cart</h1>


        <table>
            <thead>
                <tr>
                    <th>Item Title</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['title']); ?></td>
                        <td><?php echo number_format($item['price'], 2); ?> €</td>
                        <td class="quantityInfo"><?php echo $item['quantity']; ?></td>
                        <td><?php echo number_format($item['price'] * $item['quantity'], 2); ?> €</td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="removeItemId" value="<?php echo $item['cartId']; ?>">
                                <button class="removeButton" type="submit">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                        
        <!--former info that can be updated-->
        <form class="informationContainer" method="post">
            <h2>User Information</h2>
            <label class="clientInfo" for="firstName">First Name:</label>
            <input   class="clientResponse" type="text" id="firstName" name="firstName" value="<?php echo htmlspecialchars($user['firstName']); ?>" required>

            <label  class="clientInfo" for="lastName">Last Name:</label>
            <input  class="clientResponse" type="text" id="lastName" name="lastName" value="<?php echo htmlspecialchars($user['lastName']); ?>" required>

            <label  class="clientInfo" for="email">Email:</label>
            <input   class="clientResponse" type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

            <label  class="clientInfo" for="address">Address:</label>
            <textarea   class="clientResponse" id="address" name="address" rows="3"><?php echo htmlspecialchars($user['address']); ?></textarea>

            <button class="updateButton" type="submit" name="updateUserDetails">Update Details</button>
        </form>

        <!--price info(+random discount percentage)-->
        <div class="mostImportantInfo">
        <h2>Total Payment</h2>
        <p class="totalPaymentInfo">Initial Amount: <?php echo number_format($initialPaymentAmount, 2); ?> €</p>
        <p class="totalPaymentInfo">Discount: <?php echo ($discountPercentage * 100); ?>%</p>
        <p class="finalAmount">Final Amount: <?php echo number_format($finalPaymentAmount, 2); ?> €</p>

        <!--order button -->
        <form method="post">
            <button class="orderButton" type="submit" name="placeOrder">Place Order</button>
        </form>
        </div>
    </div>
</main>
    <footer>
    <div class="footerContainer">
            <div class="contactInfo">
                <p><strong>WhimsyWear Clothing</strong></p>
                <p><a  href="tel:+1234567890">+123 456 7890</a></p>
                <p><a  href="mailto:buzialexandra@gmail.com">buzialexandra@gmail.com</a></p>
                <p>Androutsou 150, Piraeus, Greece</p>
            </div>
            <div class="map">
                <h3>Our Location</h3>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3133.2880325410413!2d23.643801615677364!3d37.94318797972616!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1bcf7b064ed27%3A0x82bf2b8d795fd2!2sAndroutsou%20150%2C%20Pireas%20185%2034%2C%20Greece!5e0!3m2!1sen!2sus!4v1625573188392!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </footer>
</body>
</html>
