    <?php
    include 'database.php';
    session_start();

    //checking if user is logged in 
    if (!isset($_SESSION['userId'])) {
        echo "<script>
            alert('Please log in to rate us.');
            window.location.href = 'loginRegister.php';
        </script>";
        exit();
    }

    //retrieve user information
    $userId = $_SESSION['userId'];

    //check if the user has made any purchases in the past
    $purchaseCheckSql = "SELECT COUNT(*) as purchaseCount FROM purchases WHERE userPurchaseId = ?";
    $purchaseCheckStmt = $conn->prepare($purchaseCheckSql);
    $purchaseCheckStmt->bind_param("i", $userId);
    $purchaseCheckStmt->execute();
    $purchaseCheckResult = $purchaseCheckStmt->get_result();
    $purchaseCount = $purchaseCheckResult->fetch_assoc()['purchaseCount'];

    //handle form submission for posting a comment
    if ($purchaseCount > 0 && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submitComment'])) {
        $comment = trim($_POST['comment']);
        
        if (!empty($comment)) {
            $insertCommentSql = "INSERT INTO comments (userId, comment) VALUES (?, ?)";
            $insertCommentStmt = $conn->prepare($insertCommentSql);
            $insertCommentStmt->bind_param("is", $userId, $comment);
            $insertCommentStmt->execute();
            echo "<script>
                alert('Comment submitted successfully!');
                window.location.href = 'rate.php';
            </script>";
            exit();
        }
    }

    //show all comments
    $commentSql="SELECT c.comment, u.username FROM comments c JOIN users u ON c.userId = u.userId ORDER BY c.commentId DESC";
    $commentResult = $conn->query($commentSql);
    ?>
    
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- link for emojis -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
        <style>
                body {
                    background-image: url("homeBackground.png");
                    background-size: cover;
            }

            .header {
                    font-family: 'Cursive', Arial;
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                    padding: 15px;
                    background-color: rgba(255, 237, 205, 0.9);
                    border-radius: 10px;
                    width: 69.5%;
                    position:relative;
                    left:14%;
            }

            .webTitle {
                    background-color: rgba(255, 237, 205, 0.9);
                    padding: 8px;
                    text-align: center;
                    color: rgb(28, 47, 111);
                    border-radius: 10px;
                    margin-bottom: 10px;
                    flex: 1;
                }

            .navigation {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    background-color: rgb(242, 168, 179);
                    padding: 10px;
                    width: 100%;
                    border-radius: 10px;
                    text-align: center;
                }

            .navigation i {
                    color: rgb(28, 47, 111);
                    padding: 10px 15px;
                    font-size: 1.2em;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 5px;
                }

            .navigation a {
                    text-decoration: none;
                    color: inherit;
                }

            .navigation i:hover {
                    background-color: rgb(247, 196, 213);
                    color: rgb(31, 136, 201);
                    border-radius: 7px;
                }

            .navigation i.active {
                    background-color: rgb(33, 55, 129);
                    color: rgb(247, 196, 213);
                    border-radius: 7px;
                }

            main {
                    background-color: rgba(255, 237, 205, 0.9);
                    opacity:0.9;
                    width:68%;
                    padding: 40px;
                    text-align:center;
                    margin:auto;
                }

            h1, h2 {
                    font-family: Cursive, Arial;
                    color: rgb(28, 47, 111);
                }

            table {
                    margin: 0 auto 30px auto;
                    width: 100%;
                    border-collapse: collapse;
                    
                }

            th, td {
                    font-family: Cursive, Arial;
                    color: rgb(28, 47, 111);
                    padding: 10px;
                    border-bottom: 1px solid #ddd;
                    text-align: center;
                
                }

            .commentForm {
                    margin: 30px 0;
                }

            .commentBox {
                    width: 100%;
                    height: 100px;
                    border: 1px solid rgb(28, 47, 111);
                    border-radius: 5px;
                    padding: 10px;
                    box-sizing: border-box;
                    font-size: 16px;
                }

            .submitButton {
                    background-color: #ed81a1;
                    color: rgb(28, 47, 111);
                    border: none;
                    border-radius: 5px;
                    padding: 10px 20px;
                    font-family: Cursive, Arial;
                    font-size: 16px;
                    cursor: pointer;
                }

            .submitButton:hover {
                    background-color: rgb(28, 47, 111);
                    color: rgba(255, 237, 205, 0.9);
                }
            .notOrderedYetAlert{
                    display:flex;
                    font-family: Cursive, Arial;
                    color:rgb(203,65,84);
                    text-decoration:underline;
                    justify-content: center;
                    font-size:18px;
                }

            footer {
                    background-color: rgba(255, 237, 205, 255);
                    border-radius: 10px;
                    padding: 10px;
                    font-family: Cursive, Arial;
                    text-align: center;
                    width: 70%;
                    margin:auto;
                    margin-top: auto; 
                }

            
            .footerContainer {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    gap: 20px;
                }

            .contactInfo {
                    background-color: rgba(255, 237, 205, 255);
                    width: 100%;
                    max-width: 500px;
                    border-radius: 10px;
                    padding: 10px;
                    color: rgb(238, 151, 164);
                    box-sizing: border-box;
                }
            .map {
                    background-color: rgba(255, 237, 205, 255);
                    width: 100%;
                    max-width: 500px;
                    border-radius: 10px;
                    padding: 10px;
                    color: rgb(238, 151, 164);
                    box-sizing: border-box;
                }


            .contactInfo p, .map h3 {
                    margin: 5px 0;
                }

            iframe {
                    width: 100%;
                    height: 200px;
                    border: 0;
                    border-radius: 10px;
                }

            a:link {
                    color: rgb(28, 47, 111);
                }

            a:hover {
                    color: rgba(255, 237, 205, 255);
                    background-color: rgb(238, 151, 164);
                    padding: 5px;
                    border-radius: 10px;
                }

            @media (max-width: 768px) {
                .footerContainer {
                    flex-direction: column;
                    gap: 10px;
                }

                .contactInfo, .map {
                    max-width: 70%;
                }

                iframe {
                    height: 300px; 
                }
            }

                </style>
        <title>Rate Us - WhimsyWear</title>
        
    </head>
    <body>

    <div class="header">
        <h1 class="webTitle"><span class="fa-solid fa-vest-patches"></span> WhimsyWear</h1>
        <div class="navigation">
            <a href="cart.php"><i class="fa-solid fa-basket-shopping"> MY CART</i></a>
            <a href="home.php"><i class="fa-solid fa-house">HOME</i></a>
            <a href="rate.php"><i class="fa-solid fa-star active">RATE US</i></a>
            <a href="logout.php"><i class="fa-solid fa-right-from-bracket">LOG OUT</i></a>
        </div>
    </div>

    <main>
        <h1>Ratings</h1>

        <!-- showing comments -->
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Comment</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $commentResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['comment']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <?php if ($purchaseCount > 0): ?>
            <!--if the user has made a purchase, allow them to submit a comment -->
            <form class="commentForm" method="post">
                <textarea class="commentBox" name="comment" placeholder="Write your comment here..." required></textarea>
                <br>
                <button class="submitButton" type="submit" name="submitComment">Submit</button>
            </form>
        <?php else: ?>
            <!--if user has not made a purchase, display alert on form submission -->
            <form class="commentForm" onsubmit="alert('You need to make a purchase to submit a comment.'); return false;">
                <textarea class="commentBox" name="comment" placeholder="Write your comment here..." disabled></textarea>
                <br>
                <button class="submitButton" type="submit" name="submitComment" disabled>Submit</button>
            </form>
            <div class="notOrderedYetAlert">Warning: You must complete a purchase before leaving a rating.</div>
        <?php endif; ?>
    </main>

    <footer>
            <div class="footerContainer">
            <div class="contactInfo">
                    <p><strong>WhimsyWear Clothing</strong></p>
                    <p><a href="tel:+1234567890">+123 456 7890</a></p>
                    <p><a href="mailto:buzialexandra@gmail.com">buzialexandra@gmail.com</a></p>
                    <p>Androutsou 150, Piraeus, Greece</p>
                </div>
                <div class="map">
                    <h3>Our Location</h3>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3133.2880325410413!2d23.643801615677364!3d37.94318797972616!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1bcf7b064ed27%3A0x82bf2b8d795fd2!2sAndroutsou%20150%2C%20Pireas%20185%2034%2C%20Greece!5e0!3m2!1sen!2sus!4v1625573188392!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </footer>

    </body>
    </html>