<?php
session_start(); //start the session to use session ID
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "d_and_s"; 

//creating connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Checking connection
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

//is user logged in?
if (!isset($_SESSION['userId'])) {
    echo "<script>
            alert('You need to log in to add products to the cart.');
            window.location.href = 'loginRegister.php'; // Redirect to the login page
          </script>";
    exit();
}

$userId = $_SESSION['userId'];//retrieving id
//adding into cart
if (isset($_POST['productId'], $_POST['quantity']) && is_numeric($_POST['productId']) && is_numeric($_POST['quantity'])) {
    $productId = intval($_POST['productId']);
    $quantity = intval($_POST['quantity']);

    $stmt = $conn->prepare("INSERT INTO cart (userId, productId, quantity) VALUES (?, ?, ?) 
                            ON DUPLICATE KEY UPDATE quantity = quantity + ?");
    $stmt->bind_param("iiii", $userId, $productId, $quantity, $quantity);

    if ($stmt->execute()) {
        echo "Product added to cart successfully";
    } else {
        echo "Error: " . htmlspecialchars($stmt->error);
    }

    $stmt->close();
} else {
    echo "Invalid product or quantity.";
}

$conn->close();

//redirecting
header("Location: home.php");
exit();
?>