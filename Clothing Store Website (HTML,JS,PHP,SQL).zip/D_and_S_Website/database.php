<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "d_and_s";

$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
} //create and establish connection (if an error occurs, the appropriate message pops up)
$sql="CREATE DATABASE IF NOT EXISTS $dbname"; //create the database only if it does not already exist
$conn->query($sql);
$conn->select_db($dbname);

$sql= "CREATE TABLE IF NOT EXISTS users (
userId INT AUTO_INCREMENT PRIMARY KEY,
firstName VARCHAR(100) NOT NULL,
lastName VARCHAR(100) NOT NULL,
username VARCHAR(100) NOT NULL UNIQUE,
userPassword VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL UNIQUE,
address TEXT NOT NULL)"; // creating the users table
$conn->query($sql);

$sql= "CREATE TABLE IF NOT EXISTS products(
productId INT AUTO_INCREMENT PRIMARY KEY,
title VARCHAR(100) NOT NULL,
productImage VARCHAR(100) NOT NULL,
price DECIMAL(10,2) NOT NULL,
availability INT NOT NULL )"; //creating the table that contains the products
$result = $conn->query("SHOW COLUMNS FROM products LIKE 'category'");
$exists = ($result->num_rows > 0) ? true : false;
if (!$exists) {
    $sql = "ALTER TABLE products 
            ADD category VARCHAR(50) NOT NULL";
    $conn->query($sql);
}
$conn->query($sql); //a new addition in the table in order to help us with the categories in the home page

$sql="CREATE TABLE IF NOT EXISTS purchases (
    purchaseId INT AUTO_INCREMENT PRIMARY KEY,
    userPurchaseId INT NOT NULL,
    productPurchaseId INT NOT NULL,
    quantity INT NOT NULL,
    purchaseDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userPurchaseId) REFERENCES users(userId),
    FOREIGN KEY (productPurchaseId) REFERENCES products(productId)
);";
//creating the table that contains the purchases made, userPurchaseId AND productPurchaseId are referenced from the table that we created above
$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS cart (
    cartId INT AUTO_INCREMENT PRIMARY KEY,
    userId INT DEFAULT NULL,
    productId INT NOT NULL,
    quantity INT DEFAULT 1,
    sessionId VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(userId) ON DELETE CASCADE,
    FOREIGN KEY (productId) REFERENCES products(productId) ON DELETE CASCADE
)";

$conn->query($sql);
//creating the table comments 

$sql = "CREATE TABLE IF NOT EXISTS comments (
    commentId INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    comment TEXT NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(userId)
)";
$conn->query($sql);

?>