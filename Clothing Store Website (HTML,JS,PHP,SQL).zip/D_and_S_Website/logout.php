<?php
session_start(); //start the session

//destroy the session to log out the user
session_unset(); // Unset all session variables
session_destroy(); //destroy the current session

// Redirect user to the home page
header("Location: home.php");
exit();
?>