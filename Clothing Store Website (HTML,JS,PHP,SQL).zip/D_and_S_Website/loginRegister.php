<?php
include 'database.php';
session_start();

$errors = [];
$registerSuccess = false; //tracking the registration process in order to show if it's successful

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //registering user through $_POST method
    if (isset($_POST['register'])) {
        $firstName= $_POST['firstName'];
        $lastName= $_POST['lastName'];
        $username= $_POST['username'];
        $userPassword= $_POST['userPassword'];
        $email= $_POST['email'];
        $address= $_POST['address'];

        //validation based on set standards
        if (!preg_match("/^[a-zA-Z]+$/", $firstName) || !preg_match("/^[a-zA-Z]+$/", $lastName)) {
            $errors[]="First name and last name must contain only characters.";
        }
        if (!preg_match("/^(?=.*[0-9])[a-zA-Z0-9]{4,10}$/", $userPassword)) {
            $errors[]="Password must be 4-10 characters long and contain at least one number.";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[]="Invalid email format.";
        }

        // Check if username or email is unique
        $checkSql="SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt=$conn->prepare($checkSql);
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows>0) {
            $errors[]="Username or email already in use.";
        }

        if (empty($errors)) {
            //hashing the set password before storing
            $hashedPassword = password_hash($userPassword, PASSWORD_DEFAULT); //unique hash for password
            $sql = "INSERT INTO users (firstName,lastName,username,userPassword, email, address) 
                    VALUES (?,?,?,?,?,?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $firstName, $lastName, $username, $hashedPassword, $email, $address);

            if ($stmt->execute()) {
                $registerSuccess = true; //success in registering
            } else {
                $errors[] = "Registration failed.";
            }
        }
    }

    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $userPassword = $_POST['userPassword'];

        //SQL query for user data
        $sql="SELECT * FROM users WHERE username = ?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows>0) {
            $user=$result->fetch_assoc();
            // Verify password
            if (password_verify($userPassword,$user['userPassword'])) {
                $_SESSION['userId'] = $user['userId']; //using userID to set each session
                header("Location: home.php");
                exit();
            } else {
                $errors[] = "Incorrect password.";
            }
        } else {
            $errors[] = "Username not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Whimsywear Login/Register</title>
    <style>
        
        html, body {
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center; /*useful for the appearance of register option*/
           
        }

        body {
            background-image: url("homeBackground.png");
            background-size: cover;
            background-attachment: fixed;
        }

       
        .header {
            font-family: Helvetica, 'Showcase Sans','Cursive', Arial;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background-color: rgba(255, 237, 205, 0.9);
            border-radius: 10px;
            width: 100%;
            display: flex;
            position:relative;
            top:200px;
             
        }

        .webTitle {
            background-color: rgba(255, 237, 205, 0.9);
            padding: 8px;
            padding-top:100px;
            text-align: center;
            color: rgb(28, 47, 111);
            border-radius: 10px;
           display:flex;
            
          
        }

        .navigation {
            display: flex;
            
            justify-content: center;
            align-items: center;
            background-color: rgb(242, 168, 179); /* Pink */
            padding: 10px;
            width: 100%;
            border-radius: 10px;
            text-align: center;
          
   
        }

        .navigation a {
           
            color: rgb(28, 47, 111);
            padding: 10px 15px;
            font-size: 1.2em;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            text-decoration:none;
        }

        .navigation a:hover {
            background-color: rgb(247, 196, 213);
            color: rgb(31, 136, 201);
            border-radius: 7px;
        }

        .navigation a.active {
            background-color: rgb(33, 55, 129);
            color: rgb(247, 196, 213);
            border-radius: 7px;
        }
        /*for the login and register forms*/
        .loginOrRegister {
            font-family: 'Cursive',Arial;
            width: 400px;
            background-color: rgba(255, 237, 205, 0.9);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin-top: 180px; 
            margin-bottom: 50px;
            
        }
        

        form {
            display: none;
            flex-direction: column;
            gap: 15px;
        }

        form.active {
            display: flex;
        }
        #form-title{
            margin:auto;
            padding-top:70px;
            padding-bottom:30px;
            font-family:cursive,arial;
            color:rgb(28, 47, 111);
        }
        .registerInfo, label{
            margin:auto;
            font-family:cursive,arial;
        }
        label {
            color: rgb(28, 47, 111);
            font-size: 20px;
            text-align: left;
        }

        input[type="text"],input[type="password"],input[type="email"],textarea {
            padding: 10px;
            border: 1px solid rgb(28, 47, 111);
            border-radius: 5px;
            font-size: 20px;
        }

        button {
            padding: 10px;
            background-color: rgb(242, 168, 179);
            color:rgb(28, 47, 111);
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 20px;
            font-family: Cursive, Arial;
           
        }

        button:hover {
            background-color: pink;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .success-message {
            color: green;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .toggle-link {
            color: rgb(242, 168, 179);
            cursor: pointer;
            
        }
        /*footer styling*/
        footer {
            background-color: rgba(255, 237, 205, 255);
            border-radius: 10px;
            padding: 10px;
            font-family: Cursive, Arial;
            text-align: center;
            width: 100%;
            margin-top: auto; 
        }

        
        .footerContainer {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }

        .contactInfo {
            background-color: rgba(255, 237, 205, 255);
            width: 100%;
            max-width: 500px;
            border-radius: 10px;
            padding: 10px;
            color: rgb(238, 151, 164);
            box-sizing: border-box;
        }
        .map {
            background-color: rgba(255, 237, 205, 255);
            width: 100%;
            max-width: 500px;
            border-radius: 10px;
            padding: 10px;
            color: rgb(238, 151, 164);
            box-sizing: border-box;
        }


        .contactInfo p, .map h3 {
            margin: 5px 0;
        }

        iframe {
            width: 100%;
            height: 200px;
            border: 0;
            border-radius: 10px;
        }



        span:hover {
            color: rgba(255, 237, 205, 255);
            background-color: rgb(238, 151, 164);
            padding: 5px;
            border-radius: 10px;
        }
        @media (max-width: 768px) {
            .footerContainer {
                flex-direction: column;
                gap: 10px;
            }

            .contactInfo, .map {
                max-width: 100%;
            }

            iframe {
                height: 300px; 
            }
        }

    </style>
    <script>
        function toggleForm(formId) {
            document.getElementById('loginForm').classList.remove('active');
            document.getElementById('register-form').classList.remove('active');

            document.getElementById(formId).classList.add('active');
            const formTitle = document.getElementById('form-title');
            if (formId === 'loginForm') {
                formTitle.textContent = 'Login';
            } else {
                formTitle.textContent = 'Register';
            }
        }
    </script>
</head>
<body>
    <div class="header">
        <h1 class="webTitle"><span class="fa-solid fa-vest-patches"></span> WhimsyWear</h1>
        <div class="navigation">
            <a href="cart.php"><i class="fa-solid fa-basket-shopping"> MY CART</i></a>
            <a href="home.php"><i class="fa-solid fa-house">HOME</i></a>
            <a href="rate.php"><i class="fa-solid fa-star">RATE US</i></a>
            <a href="loginRegister.php" class="active"><i class="fa-solid fa-user active"> LOGIN / REGISTER</i></a>
        </div>
    </div>

    <div class="loginOrRegister">
        <?php if ($registerSuccess): ?>
            <p class="success-message">Registration successful! Please log in.</p>
        <?php endif; ?>

        <h2 id="form-title">Login</h2>
        <form id="loginForm" class="active" method="post">
            <label for="login-username">Username:</label>
            <input type="text" id="login-username" name="username" required>
            <label for="login-password">Password:</label>
            <input type="password" id="login-password" name="userPassword" required>
            <button type="submit" name="login">Login</button>
            <p>Don't have an account? <span class="toggle-link" onclick="toggleForm('register-form')">Register here</span></p>
        </form>
        
        <form id="register-form" method="post">
        <h2 id="form-title">Register</h2>
            <label for="firstName"><div class="registerInfo">First Name:</div></label>
            <input type="text" id="firstName" name="firstName" required>
            <label for="lastName"><div class="registerInfo">Last Name:</div></label>
            <input type="text" id="lastName" name="lastName" required>
            <label for="register-username"><div class="registerInfo">Username:</div></label>
            <input type="text" id="register-username" name="username" required>
            <label for="register-password"><div class="registerInfo">Password:</div></label>
            <input type="password" id="register-password" name="userPassword" required>
            <label for="email"><div class="registerInfo">Email:</div></label>
            <input type="email" id="email" name="email" required>
            <label for="address"><div class="registerInfo">Address:</div></label>
            <textarea id="address" name="address" rows="3"></textarea>
            <button type="submit" name="register">Register</button>
            <p>Already have an account? <span class="toggle-link" onclick="toggleForm('loginForm')">Log in here</span></p>
        </form>

        <?php if (!empty($errors)): ?>
            <?php foreach ($errors as $error): ?>
                <p class="error-message"><?php echo $error; ?></p>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
<footer>
    <div class="footerContainer">
        <div class="contactInfo">
            <p><strong>WhimsyWear Clothing</strong></p>
            <p><span href="tel:+1234567890">+123 456 7890</></span>
            <p><span href="mailto:buzialexandra@gmail.com">buzialexandra@gmail.com</span></p>
            <p>Androutsou 150, Piraeus, Greece</p>
        </div>
        <div class="map">
            <h3>Our Location</h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3133.2880325410413!2d23.643801615677364!3d37.94318797972616!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1bcf7b064ed27%3A0x82bf2b8d795fd2!2sAndroutsou%20150%2C%20Pireas%20185%2034%2C%20Greece!5e0!3m2!1sen!2sus!4v1625573188392!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </div>
</footer>
</html>