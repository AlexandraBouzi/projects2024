import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

//Acceptable Property Types: "Agricultural", "Commercial", "Industrial", "Residential", "Special Purpose"
//Acceptable Owner Types: "Company", "Individual"

// From the entities : b_a = branch address, b_e = branch_email, b_p = branch phone number, e_a = employee address , e_e = employee email
// e_n = employee name, e_p = employee phone number, o_a = owner address, o_e = owner email, o_n = owner number, o_p = owner phone number
// t_a = tenant address, t_e = tenant email, t_n = tenant name, t_p = tenant phone number, p_a = property address, p_e = property employee

public class MysqlConnect {
	
	public void insertProperty(Connection conn) throws SQLException {
		// Define the variables
		String propertyType, propertyId, branchId, employeeId, employeeGender, employeePosition, addressId;
		String street, city;
		int size, streetNum, postCode, employeeSalary;
		
		System.out.println("Please insert the property information.");
		Scanner scanner = new Scanner(System.in);
		
		// Request and obtain property ID
		System.out.print("Enter property ID: ");
		propertyId = scanner.next();
		
		// Request and obtain property size
		do {
			System.out.print("Enter property size ( in square meters ): ");
			size = scanner.nextInt();
			if (size<0) {
				System.out.print("Invalid input.Please try again\n");
			}
		}while (size<0);

		scanner.nextLine(); // Clear the buffer
     
		// Request and obtain property type with validation
		System.out.print("Enter property type (Acceptable Property Types: \"Agricultural\", "
						+ "\"Commercial\", \"Industrial\", \"Residential\", \"Special Purpose\"): ");
	    do {
	    	propertyType = scanner.nextLine();
	        if (!propertyType.equals("Agricultural") && !propertyType.equals("Commercial") && !propertyType.equals("Industrial") 
	        	&& !propertyType.equals("Residential") && !propertyType.equals("Special Purpose") ) {
	        	
	        	System.out.println("Invalid input. Please enter again:");
	        }
	    } while (!propertyType.equals("Agricultural") && !propertyType.equals("Commercial") && !propertyType.equals("Industrial") 
	    		&& !propertyType.equals("Residential") && !propertyType.equals("Special Purpose"));
	    
	    // CREATE BRANCH ENTITY
	    
	    // Request and obtain branch ID
	    System.out.print("Enter branch id: ");
	    branchId = scanner.next();
	    
	    String enterBranchQuery = "INSERT INTO branch (branch_id) VALUES (?)";
	    
	    // Create prepared statement
	    PreparedStatement preparedStatementp = conn.prepareStatement(enterBranchQuery);

		// Set parameter values for the prepared statement
		preparedStatementp.setString(1, branchId);
	    
	    // Execute the prepared statement to insert the property into the database
	    int rowsAffectedPropertyp = preparedStatementp.executeUpdate();
	    
	    if (rowsAffectedPropertyp > 0) {
	    	System.out.println("Branch Insert successful!");
	    } else {
	    	System.out.println("Branch Insert failed!");
	    }
 	
	    // This closes the prepared statement
	    preparedStatementp.close();
	    
	    // CREATE EMPLOYEE ENTITY
	    
	    // Request and obtain employee ID
	    System.out.print("Enter employee id: ");
	    employeeId = scanner.next();
	    
	    // Request and obtain employee gender
	    do {
	    		    System.out.print("Enter employee gender (Female OR Male): ");
	    employeeGender = scanner.next();
	    if (!employeeGender.equals("Female")&&!employeeGender.equals("Male")) {
	    	System.out.println("Invalid input.Please try again\n");
	    }
	    }while (!employeeGender.equals("Female")&&!employeeGender.equals("Male"));

	    
	    // Request and obtain employee position
	    System.out.print("Enter employee position: ");
	    employeePosition = scanner.next();
	 
	    // Request and obtain employee salary
	    do {
		    System.out.print("Enter employee salary: ");
		    employeeSalary = scanner.nextInt();
		    if (employeeSalary<0) {
		    	System.out.println("Invalid input.Please try again\n");
		    }
	    }while (employeeSalary<0);


	    String enterEmployeeQuery = "INSERT INTO emplo (employee_id, gender, position, salary, branch_branch_id) VALUES (?, ?, ?, ?, ?)";
	    
	    // Create prepared statement
	    PreparedStatement preparedStatement0 = conn.prepareStatement(enterEmployeeQuery);

		// Set parameter values for the prepared statement
		preparedStatement0.setString(1, employeeId);
		preparedStatement0.setString(2, employeeGender);
		preparedStatement0.setString(3, employeePosition);    
		preparedStatement0.setInt(4, employeeSalary);
		preparedStatement0.setString(5, branchId);
	    
	    // Execute the prepared statement to insert the property into the database
	    int rowsAffectedProperty0 = preparedStatement0.executeUpdate();
	    
	    if (rowsAffectedProperty0 > 0) {
	    	System.out.println("Employee Insert successful!");
	    } else {
	    	System.out.println("Employee Insert failed!");
	    }
 	
	    // This closes the prepared statement
	    preparedStatement0.close();
	    
	    // CREATE PROPERTY ENTITY
     
	    String enterPropertyQuery = "INSERT INTO property (property_id, Size, type, tenant_tenant_id, "
	    						+ "branch_branch_id) VALUES (?, ?, ?, NULL, ?)";

	    // Create prepared statement
	    PreparedStatement preparedStatement = conn.prepareStatement(enterPropertyQuery);

		// Set parameter values for the prepared statement
		preparedStatement.setString(1, propertyId);
		preparedStatement.setInt(2, size);
		preparedStatement.setString(3, propertyType);    
		preparedStatement.setString(4, branchId);
	    
	    // Execute the prepared statement to insert the property into the database
	    int rowsAffectedProperty = preparedStatement.executeUpdate();
	    
	    if (rowsAffectedProperty > 0) {
	    	System.out.println("Property Insert successful!");
	    } else {
	    	System.out.println("PropertyInsert failed!");
	    }
 	
	    // This closes the prepared statement
	    preparedStatement.close();
 	
	    // CREATE CONNECTION ENTITY BETWEEN PROPERTY AND EMPLOYEE
	    
	    String enterP_EQuery = "INSERT INTO p_e (property_property_id, emplo_employee_id) VALUES (?, ?)";
	    
	    // Create prepared statement
	    PreparedStatement preparedStatement1 = conn.prepareStatement(enterP_EQuery);

		// Set parameter values for the prepared statement
		preparedStatement1.setString(1, propertyId);
		preparedStatement1.setString(2, employeeId);
	    
	    // Execute the prepared statement to insert the property into the database
	    int rowsAffectedProperty1 = preparedStatement1.executeUpdate();
	    
	    if (rowsAffectedProperty1 > 0) {
	    	System.out.println("Property Employee connection Insert successful!");
	    } else {
	    	System.out.println("Property Employee connection failed!");
	    }
	    
	    // This closes the prepared statement
	    preparedStatement1.close();
	    
	    // CREATE ADDRESS ENTITY
     
	    // Request and obtain street
	    System.out.print("\nEnter the street: ");
	    street = scanner.next();
	 
	    // Request and obtain street Number
	    System.out.print("\nEnter the street number: ");
	    streetNum = scanner.nextInt();
	    
	    scanner.nextLine(); // Clear the buffer
	    
	    // Request and obtain city
	    System.out.print("\nEnter the city: ");
	    city = scanner.next();
	    
	    // Request and obtain Post Code
	    System.out.print("\nEnter the postal code: ");
	    postCode = scanner.nextInt();

	    // Create the address ID
	    addressId = street + Integer.toString(streetNum) + city + Integer.toString(postCode);
	    
	    String enterAddressQuery = "INSERT INTO address (`address_id`, `street`, `street_num`, `city`, `P.C_`) VALUES (?, ?, ?, ?, ?)";

	    // Create prepared statement
	    PreparedStatement preparedStatement2 = conn.prepareStatement(enterAddressQuery);

	    // Set parameter values for the prepared statement
	    preparedStatement2.setString(1, addressId);
	    preparedStatement2.setString(2, street);
	    preparedStatement2.setInt(3, streetNum);
	    preparedStatement2.setString(4, city);
	    preparedStatement2.setInt(5, postCode);

	    // Execute the prepared statement to insert the address into the database
	    int rowsAffectedAddress = preparedStatement2.executeUpdate();
	    
	    if (rowsAffectedAddress> 0) {
	        System.out.println("Address details Insert successful!\n");
	    } else {
	        System.out.println("Address details Insert failed!\n");
	    }
 	
	    // This closes the prepared statement
	    preparedStatement2.close();
	    
	    // CREATE CONNECTION ENTITY BETWEEN ADDRESS AND PROPERTY
	    
	    String enterPAddQuery = "INSERT INTO p_a ( address_address_id, property_property_id ) VALUES (?, ?)";
	    
	    // Create prepared statement
	    PreparedStatement pAddStatement = conn.prepareStatement(enterPAddQuery);
	    
	    // Set parameter values for the prepared statement
	    pAddStatement.setString(1, addressId);
	    pAddStatement.setString(2, propertyId);

	    // Execute the prepared statement
        int rowsAffectedPAddress = pAddStatement.executeUpdate();
	    
	    if (rowsAffectedPAddress> 0) {
	        System.out.println("Property address details Insert successful!\n");
	    } else {
	        System.out.println("Property address details Insert failed!\n");
	    }
	    
	    // This closes the prepared statement
	    pAddStatement.close();
	    
	    System.out.println("\nThe address ID is from now on: " + addressId );
	    
	}

	public void insertCustomer(Connection conn) throws SQLException {
		// Define the variables
	    String nameId, tPNum,concNameId, ownerName, ownerSurname, ownerPatronymic, concOName,tenantId, type, name;
	    String addressId, surname, patronymic, ownerId, companyName, emaill;;
	    int emailnum, i , pNumNum;

	    System.out.println("Please insert the customer information.");
	    Scanner scanner = new Scanner(System.in);

	    // Request and obtain customer type with input validation
	    System.out.print("\nEnter the customer type (Individual or Company): ");
	    do {
	        type = scanner.next();
	        if (!type.equals("Individual") && !type.equals("Company")) {
	            System.out.println("Invalid input. Please enter again\n");
	        }
	    	System.out.print("\nEnter tenant id:");
	    	tenantId=scanner.next();
            
            String enterTenantQuery = "INSERT INTO tenant (tenant_id, type) VALUES (?, ?)";

	        // Create prepared statement
	        PreparedStatement preparedStatement4 = conn.prepareStatement(enterTenantQuery);

	        // Set parameter values for the prepared statement
	        preparedStatement4.setString(1, tenantId);
	        preparedStatement4.setString(2, type);
	       
	        // Execute the query
	        int rowsAffectedTenant = preparedStatement4.executeUpdate();
	        if (rowsAffectedTenant > 0) {
	            System.out.println("Tenant details insert successful!");
	        } else {
	            System.out.println("Tenant details insert failed!");
	        }
	        preparedStatement4.close();

	    } while (!type.equals("Individual") && !type.equals("Company"));

	    // If the user chose Individual
	    if (type.equals("Individual")) {
	    	
	    	System.out.print("You chose the individual option.\n");

	        // Request and obtain name
	        System.out.print("\nEnter name:");
	        name = scanner.next();

	        // Request and obtain surname
	        System.out.print("\nEnter surname:");
	        surname = scanner.next();

	        // Request and obtain patronymic
	        System.out.print("\nEnter patronymic:");
	        patronymic = scanner.next();
	        
	        concNameId = name + surname ;

	        String enterNameQuery = "INSERT INTO name (name_id, firstname, patronymic, surname, companyname ) VALUES (?, ?, ?, ?, NULL)";

	        // Create prepared statement
	        PreparedStatement preparedStatement3 = conn.prepareStatement(enterNameQuery);

	        // Set parameter values for the prepared statement
	        preparedStatement3.setString(1, concNameId);
	        preparedStatement3.setString(2, name);
	        preparedStatement3.setString(3, patronymic);
	        preparedStatement3.setString(4, surname);													   											   

	        // Execute the query
	        int rowsAffectedName = preparedStatement3.executeUpdate();

	        String enterTNameQuery = "INSERT INTO t_n (tenant_tenant_id, name_name_id) VALUES (? ,?)";
	        PreparedStatement tNameStatement = conn.prepareStatement(enterTNameQuery);
	        tNameStatement.setString(1, tenantId);
	        tNameStatement.setString(2, concNameId);
	        int tAff = tNameStatement.executeUpdate();
	        if (tAff > 0) {
	            System.out.println("--------------");
	        } else {
	            System.out.println("................");
	        }
	        if (rowsAffectedName > 0) {
	            System.out.println("Name details insert successful!");
	        } else {
	            System.out.println("Name details insert failed!");
	        }
	        tNameStatement.close();
	        // Close the statement
	        preparedStatement3.close();
	        do {
		        System.out.println( "Enter how many emails you'd like to submit" );
	            emailnum = scanner.nextInt();
	            if (emailnum<0) {
	    	        System.out.println( "Invalid input.Please try again");
	            }
	        }while (emailnum<0);

            
            i = 0;
            while ( i < emailnum ) {
            	
            	System.out.println( "Enter new email#" + ( i + 1 ) + ": " );
            	emaill = scanner.next();
            	String enterMainTEmailQuery= "INSERT INTO email (email) VALUES (?) ";
            	PreparedStatement mainTEmailStatement = conn.prepareStatement(enterMainTEmailQuery);
            	mainTEmailStatement.setString(1, emaill);
            	int rowsAffectedMainTEmail= mainTEmailStatement.executeUpdate();
            	if (rowsAffectedMainTEmail > 0 ) {
            		System.out.print("\n~~~~~~\n");
            	}
            	mainTEmailStatement.close();
            	String enterEmailQuery = "INSERT INTO t_e ( tenant_tenant_id, email_email ) VALUES (?, ?)";
            	
            	// Create prepared statement
            	PreparedStatement preparedStatement5 = conn.prepareStatement(enterEmailQuery);
            	
            	// Set parameter values for the prepared statement\
            	preparedStatement5.setString(1 , tenantId);
            	preparedStatement5.setString(2 ,emaill);
            	
            	// Execute the query
            	int rowsAffectedEmail = preparedStatement5.executeUpdate();
            	
            	if (rowsAffectedEmail > 0) {
            		System.out.println("Email details insert successful!");
            	} else {
            		System.out.println("Email details insert failed!");
            	}
            	
            	i++;
            	// Close the statement
            	preparedStatement5.close();
            }
            do {
                System.out.println("Enter how many phone numbers you'd like to submit");
                pNumNum=scanner.nextInt();
                if (pNumNum<0) {
                	System.out.println("Invalid input.Please try again.\n");
                }
            }while ( pNumNum<0);
            int j=0;
            while (j<pNumNum) {
            	System.out.println( "Enter new phone number#" + ( j + 1 ) + ": " );	
            	tPNum = scanner.next();
            	String enterMainTNumQuery="INSERT INTO phonenumber (phone) values (?)";
            	PreparedStatement mainTPNumStatement = conn.prepareStatement(enterMainTNumQuery);
            	mainTPNumStatement.setString(1,tPNum);
            	int rowsAffectedMainTPNum = mainTPNumStatement.executeUpdate();
            	if (rowsAffectedMainTPNum > 0 ) {
            		System.out.print("\n~~~~~~\n");
            	}
            	mainTPNumStatement.close();
            	String enterTNumQuery = "INSERT INTO t_p (tenant_tenant_id , phonenumber_phone) VALUES ( ? ,?)";
            	PreparedStatement tPNumStatement = conn.prepareStatement(enterTNumQuery);
            	tPNumStatement.setString(1, tenantId);
            	tPNumStatement.setString(2, tPNum);
            	int rowsAffectedTPNum = tPNumStatement.executeUpdate();
            	if (rowsAffectedTPNum > 0) {
            		System.out.println("Phone number details insert successful!");
            	} else {
            		System.out.println("Phone number details insert failed!");
            	}
            	j++;
            	tPNumStatement.close();
            }
            System.out.println("Your unique name ID is:" +concNameId);
            
	    } else {

	        System.out.print("You chose the company option.\n");

	        // Request and obtain company name
	        System.out.print("\nEnter the company name:");
	        companyName = scanner.next();

	        // Request and obtain owner ID
	        System.out.print("\nEnter the owner id:");
	        ownerId = scanner.next();

	        concOName = ownerId + companyName ;
	        
	        String enterOwnerQuery = "INSERT INTO owner (owner_id, owner_type) VALUES  ( ?,?)";
	        PreparedStatement ownStatement = conn.prepareStatement(enterOwnerQuery);
	        ownStatement.setString(1, ownerId);
	        ownStatement.setString(2, type);
	       int ownRowsAff= ownStatement.executeUpdate();
	       if (ownRowsAff > 0) {
       		System.out.println("Owner details insert successful!");
       	} else {
       		System.out.println("Owner details insert failed!");
       	}
	       
	       // Request and obtain address ID
	        System.out.print("\nEnter address ID:");
	        addressId = scanner.next();

	        String enterNameOwnerQuery = "INSERT INTO name (name_id, firstname, patronymic, surname, companyname) VALUES ( ?, NULL, NULL, NULL, ?)";
	   
	        // Create prepared statement
	        PreparedStatement preparedStatement5 = conn.prepareStatement(enterNameOwnerQuery);

	        // Set parameter values for the prepared statement
	        preparedStatement5.setString(1, concOName);
	        preparedStatement5.setString(2, companyName);				  

	        // Execute the query
	        int rowsAffectedNameOwner = preparedStatement5.executeUpdate();
	        if (rowsAffectedNameOwner > 0) {
	            System.out.println("Name details insert successful!");
	        } else {
	            System.out.println("Name details insert failed!");
	        }

	        // Close the statements
	        preparedStatement5.close();
	       
	        String enterONameQuery = "INSERT INTO o_n (name_name_id , owner_owner_id ) VALUES ( ? ,?)";
	        
	        PreparedStatement oNameStatement= conn.prepareStatement(enterONameQuery);
	        
	        oNameStatement.setString(1, concOName );
	        oNameStatement.setString(2, ownerId);
	        int oNRow= oNameStatement.executeUpdate();
	        if (oNRow > 0) {
	       		System.out.println("Details insert successful!");
	       	} else {
	       		System.out.println("Details insert failed!");
	       	}
	       
	        
	        System.out.println( "Enter how many emails you'd like to submit" );
            emailnum = scanner.nextInt();
            
            i = 0;
            while ( i < emailnum ) {
            	
            	System.out.println( "Enter new email#" + ( i + 1 ) + ": " );
            	emaill = scanner.next();
            	String enterMainOEmailQuery= "INSERT INTO email (email) VALUES (?) ";
            	PreparedStatement mainOEmailStatement = conn.prepareStatement(enterMainOEmailQuery);
            	mainOEmailStatement.setString(1, emaill);
            	int rowsAffectedMainOEmail= mainOEmailStatement.executeUpdate();
            	if (rowsAffectedMainOEmail > 0 ) {
            		System.out.print("\n~~~~~~\n");
            	}
            	mainOEmailStatement.close();
            	
            	String enterEmailQuery = "INSERT INTO o_e ( owner_owner_id, email_email ) VALUES (?, ?)";
            	
            	// Create prepared statement
            	PreparedStatement oPNumpreparedStatement = conn.prepareStatement(enterEmailQuery);
            	
            	// Set parameter values for the prepared statement\
            	oPNumpreparedStatement.setString(1 , ownerId);
            	oPNumpreparedStatement.setString(2 ,emaill);
            	
            	// Execute the query
            	int rowsAffectedEmail = oPNumpreparedStatement.executeUpdate();
            	
            	if (rowsAffectedEmail > 0) {
            		System.out.println("Email details insert successful!");
            	} else {
            		System.out.println("Email details insert failed!");
            	}
            	
            	i++;
            	// Close the statement
            	oPNumpreparedStatement.close();
            }
            System.out.println("Enter how many phone numbers you'd like to submit");
            pNumNum=scanner.nextInt();
            int j=0;
            while (j<pNumNum) {
            	System.out.println( "Enter new phone number#" + ( j + 1 ) + ": " );	
            	tPNum = scanner.next();
            	String enterMainONumQuery="INSERT INTO phonenumber (phone) values (?)";
            	PreparedStatement mainOPNumStatement = conn.prepareStatement(enterMainONumQuery);
            	mainOPNumStatement.setString(1,tPNum);
            	int rowsAffectedMainOPNum = mainOPNumStatement.executeUpdate();
            	if (rowsAffectedMainOPNum > 0 ) {
            		System.out.print("\n~~~~~~\n");
            	}
            	mainOPNumStatement.close();
            	String enterTNumQuery = "INSERT INTO o_p (owner_owner_id , phonenumber_phone) VALUES ( ? ,?)";
            	PreparedStatement oPNumStatement = conn.prepareStatement(enterTNumQuery);
            	oPNumStatement.setString(1, ownerId);
            	oPNumStatement.setString(2, tPNum);
            	int rowsAffectedOPNum = oPNumStatement.executeUpdate();
            	if (rowsAffectedOPNum > 0) {
            		System.out.println("Phone number details insert successful!");
            	} else {
            		System.out.println("Phone number details insert failed!");
            	}
            	j++;
            	oPNumStatement.close();
            }
            System.out.print("\nYour unique name id is:" +concOName);
	    }
	    
	}

	public void insertRentalProperty(Connection conn) throws SQLException {

		// Define the variables
	  	String propertyType, propertyId, tenantId, branchId, employeeId;
	 	String street, city, ownerId;
	 	int size, streetNum, postCode;
	  	
	 	System.out.print("You chose to insert a rental property\nLet's insert the property details first..\n");
	 	Scanner scanner = new Scanner(System.in);
	 	
	 	// Request and obtain property ID
	 	System.out.print("Enter property ID: ");
	 	propertyId = scanner.next();
	 	
	 	// Request and obtain property size
	 	do {
		 	System.out.print("Enter property size: ");
		 	size = scanner.nextInt();
		  if (size<0) {
			  System.out.print("\nInvalid input.Please try again\n");
		  }
	 	}while (size<0);

	 	scanner.nextLine(); // Clear the buffer
	  
	 	// Request and obtain property type with validation
	 	System.out.print("Enter property type (Acceptable Property Types: \"Agricultural\", "
	 					+ "\"Commercial\", \"Industrial\", \"Residential\", \"Special Purpose\"): ");
	     do {
	     	propertyType = scanner.nextLine();
	     	if (!propertyType.equals("Agricultural") && !propertyType.equals("Commercial") && !propertyType.equals("Industrial") 
	     		&& !propertyType.equals("Residential") && !propertyType.equals("Special Purpose") ) {
	         	
	         	System.out.println("Invalid input. Please enter again:");
	        }
	     } while (!propertyType.equals("Agricultural") && !propertyType.equals("Commercial") && !propertyType.equals("Industrial") 
	     		&& !propertyType.equals("Residential") && !propertyType.equals("Special Purpose"));
	  	
	     
	     // Request and obtain tenant ID
	     System.out.print("\nEnter tenant id: ");
	     tenantId = scanner.next();
	     System.out.print("\nEnter branch id:");
	     branchId = scanner.next();
	     String enterBranchQuery = "INSERT INTO branch (branch_id) VALUES (?)";
		    
		    // Create prepared statement
		    PreparedStatement preparedStatementp = conn.prepareStatement(enterBranchQuery);

			// Set parameter values for the prepared statement
			preparedStatementp.setString(1, branchId);
		    
		    // Execute the prepared statement to insert the property into the database
		    int rowsAffectedPropertyp = preparedStatementp.executeUpdate();
	         if (rowsAffectedPropertyp>0) {
	        	 System.out.println("~~~~~~~~~~~~~~~~~~\n");
	         }
	  // CREATE EMPLOYEE ENTITY
		    
		    // Request and obtain employee ID
		    System.out.print("Enter employee id: ");
		    employeeId = scanner.next();
		    // Request and obtain employee gender
		    System.out.print("Enter employee gender: ");
		    String employeeGender = scanner.next();
		    // Request and obtain employee position
		    System.out.print("Enter employee position: ");
		    String employeePosition = scanner.next();
		 
		    // Request and obtain employee salary
		    System.out.print("Enter employee salary: ");
		    int employeeSalary = scanner.nextInt();	
		    System.out.print("\nEnter the customer type (Individual or Company): ");
		    String type;
		    do {
		          type = scanner.next();
		        if (!type.equals("Individual") && !type.equals("Company")) {
		            System.out.println("Invalid input. Please enter again:");
		        }}while (!type.equals("Individual")&&!type.equals("Company"));
		    
		    String enterTenantQuery = "INSERT INTO tenant (tenant_id, type) VALUES (?, ?)";

	        // Create prepared statement
	        PreparedStatement preparedStatement4 = conn.prepareStatement(enterTenantQuery);

	        // Set parameter values for the prepared statement
	        preparedStatement4.setString(1, tenantId);
	        preparedStatement4.setString(2, type);
	       
	        // Execute the query
	        int rowsAffectedTenant = preparedStatement4.executeUpdate();
	        if (rowsAffectedTenant > 0) {
	            System.out.println("Tenant details insert successful!");
	        } else {
	            System.out.println("Tenant details insert failed!");
	        }
	        preparedStatement4.close();
	     
	     
	     String enterPropertyQuery = "INSERT INTO property (property_id, Size, type, tenant_tenant_id, "
					+ "branch_branch_id) VALUES (?, ?, ?, ?, ?)";

          // Create prepared statement
          PreparedStatement preparedStatement = conn.prepareStatement(enterPropertyQuery);

          // Set parameter values for the prepared statement
          preparedStatement.setString(1, propertyId);
          preparedStatement.setInt(2, size);
          preparedStatement.setString(3, propertyType);    
          preparedStatement.setString(4, tenantId);
          preparedStatement.setString(5, branchId);
        

          // Execute the prepared statement to insert the property into the database
          int rowsAffectedProperty = preparedStatement.executeUpdate();

          if (rowsAffectedProperty > 0) {
          System.out.println("Property Insert successful!");
          } else {
          System.out.println("PropertyInsert failed!");
          }

	     // This closes the prepared statement
	     preparedStatement.close();
	     
	     String enterEmployeeQuery = "INSERT INTO emplo (employee_id, gender, position, salary, branch_branch_id) VALUES (?, ?, ?, ?,?)";
		    
		    // Create prepared statement
		    PreparedStatement preparedStatement0 = conn.prepareStatement(enterEmployeeQuery);

			// Set parameter values for the prepared statement
			preparedStatement0.setString(1, employeeId);
			preparedStatement0.setString(2, employeeGender);
			preparedStatement0.setString(3, employeePosition);    
			preparedStatement0.setInt(4, employeeSalary);
			
			preparedStatement0.setString(5, branchId);
		    
		    // Execute the prepared statement to insert the property into the database
		    int rowsAffectedProperty0 = preparedStatement0.executeUpdate();
		    
		    if (rowsAffectedProperty0 > 0) {
		    	System.out.println("Employee Insert successful!");
		    } else {
		    	System.out.println("Employee Insert failed!");
		    }
	 	
		    // This closes the prepared statement
		    preparedStatement0.close();
	     
	     // Request and obtain street
	     System.out.print("\nEnter the street: ");
	 	 street = scanner.next();
	 	 
	 	 // Request and obtain street Number
	 	 System.out.print("\nEnter the street Number: ");
	 	 streetNum = scanner.nextInt();
	 	 
	 	 scanner.nextLine(); // Clear the buffer
	 	    
	 	 // Request and obtain city
	 	 System.out.print("\nEnter the city: ");
	 	 city = scanner.next();
	 	    
	 	 // Request and obtain Post Code
	 	 System.out.print("\nEnter the postal code: ");
	 	 postCode = scanner.nextInt();
	 		
	 	 // Request and obtain Owner ID
	 	 System.out.print("\nEnter the owner Id: ");
	 	 ownerId = scanner.next();
	 	// Create the address ID
		    String addressId = street + Integer.toString(streetNum) + city + Integer.toString(postCode);
		    
		    String enterAddressQuery = "INSERT INTO address (`address_id`, `street`, `street_num`, `city`, `P.C_`) VALUES (?, ?, ?, ?, ?)";

		    // Create prepared statement
		    PreparedStatement preparedStatement2 = conn.prepareStatement(enterAddressQuery);

		    // Set parameter values for the prepared statement
		    preparedStatement2.setString(1, addressId);
		    preparedStatement2.setString(2, street);
		    preparedStatement2.setInt(3, streetNum);
		    preparedStatement2.setString(4, city);
		    preparedStatement2.setInt(5, postCode);

		    // Execute the prepared statement to insert the address into the database
		    int rowsAffectedAddress = preparedStatement2.executeUpdate();
		    
		    if (rowsAffectedAddress> 0) {
		        System.out.println("Address details Insert successful!\n");
		    } else {
		        System.out.println("Address details Insert failed!\n");
		    }
	  	
	 	 // This closes the prepared statement
	 	 preparedStatement2.close();  
	 	 
 
		 
	 	System.out.print("\n~~~~~~\n");
        System.out.print("Enter lease Id:");
        String leaseId=scanner.next();

        scanner.nextLine(); // Consume the newline character

        System.out.print("\nEnter sign date (yyyy-MM-dd):");
        String signnDate = scanner.nextLine();

        System.out.print("\nEnter start date (yyyy-MM-dd):");
        String startDate = scanner.nextLine();

        System.out.print("\nEnter end date (yyyy-MM-dd):");
        String endDate = scanner.nextLine();

        String enterLeaseQuery= "INSERT INTO lease (lease_id, sign_date, start_date, end_date, property_property_id, tenant_tenant_id) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement leaseStatement = conn.prepareStatement(enterLeaseQuery);
        leaseStatement.setString(1, leaseId);
        leaseStatement.setString(2,signnDate);
        leaseStatement.setString(3, startDate);
        leaseStatement.setString(4, endDate);
        leaseStatement.setString(5, propertyId);
        leaseStatement.setString(6, tenantId);
        int affRowsLease= leaseStatement.executeUpdate();
        if (affRowsLease > 0) {
            System.out.println("Lease details insert successful!");
        } else {
            System.out.println("Lease details insert failed!");
        }

        // Close the statement
        leaseStatement.close();
	  	System.out.print("Let's insert the property view details\n");
	  	System.out.print("Please submit the amount of times you viewed the specific property\n");
	  	int viewCounter, x;
	  	viewCounter = scanner.nextInt();
	  	x=0;
	
        while ( x < viewCounter ) {
        	
        	System.out.println( "Enter view date (yyyy-MM-dd)#" + ( x + 1 ) + ": " );
        	String viewwDate = scanner.next();
        	String enterViewingQuery= "INSERT INTO viewing (view_date,tenant_tenant_id,property_property_id) VALUES (?,?,?) ";
        	PreparedStatement viewingStatement = conn.prepareStatement(enterViewingQuery);
        	viewingStatement.setString(1, viewwDate);
        	viewingStatement.setString(2, tenantId);
        	viewingStatement.setString(3, propertyId);
        	int rowsAffectedViewing= viewingStatement.executeUpdate();
        	if (rowsAffectedViewing > 0 ) {
        		System.out.print("\n~~~~~~\n");
        	}
        	viewingStatement.close();
        	x++;
        }
        String answer;
        int adCounter;
        int c = 0, n = 0;
        int newsNum;

        do {
            System.out.print("Is the rental property advertised? (y/n)\n");
            answer = scanner.next();
            if (!answer.equals("y") && !answer.equals("n")) {
                System.out.print("\nInvalid input. Please try again.\n");
            }
        } while (!answer.equals("y") && !answer.equals("n"));

        if (answer.equals("y")) {
            do {
                System.out.print("How many advertisements would you like to enter?\n");
                adCounter = scanner.nextInt();
                if (adCounter < 1) {
                    System.out.print("Please try again.\n");
                }
            } while (adCounter < 1);

            while (c < adCounter) {
                System.out.println("Enter advertisement date (yyyy-MM-dd)#" + (c + 1) + ": ");
                String addDate = scanner.next();
                Double rentalAdId ; // Concatenate propertyId and addDate with a separator

                System.out.println("Please enter the unique id of the advertisment batch (double value)\n");
                rentalAdId = scanner.nextDouble();
                String enterAdQuery = "INSERT INTO rental_ad (ad_date, property_property_id, rental_ad_id) VALUES (?, ?, ?)";
                PreparedStatement adStatement = conn.prepareStatement(enterAdQuery);
                adStatement.setString(1, addDate);
                adStatement.setString(2, propertyId);
                adStatement.setDouble(3, rentalAdId);
                int rowsAffectedAd = adStatement.executeUpdate();
                if (rowsAffectedAd > 0) {
                    System.out.print("\n~~~~~~\n");
                }
                adStatement.close();
                c++;
            }
        	do {
            	System.out.print("How many of the advertisments are on the newspaper?\n");
            	newsNum=scanner.nextInt();
            	if (adCounter<0) {
            		System.out.print("Please try again");
            	}
            	}while (adCounter<0);
        	
                while ( n < newsNum ) {
            	
            	System.out.println( "Enter newspaper name#" + ( n + 1 ) + ": " );
            	String nAddName = scanner.next();
            	System.out.println("Enter the ID of the rental property advertisment #"+ ( n + 1 ) + ": " );
            	Double nRentalAd;
            	nRentalAd = scanner.nextDouble();
            	String enterNAdQuery= "INSERT INTO newspaper (name,rental_ad_rental_ad_id) VALUES (?,?) ";
            	PreparedStatement nAdStatement = conn.prepareStatement(enterNAdQuery);
            	nAdStatement.setString(1, nAddName);
            	nAdStatement.setDouble(2, nRentalAd);
            	int rowsAffectedAd= nAdStatement.executeUpdate();
            	if (rowsAffectedAd > 0 ) {
            		System.out.print("\n~~~~~~\n");
            	}
            	nAdStatement.close();
            	n++;
            }
        }
	}
	
	public void updateProperty(Connection conn) throws SQLException {	

		Scanner scanner = new Scanner(System.in);
         
		System.out.print("Enter the property ID to update: ");
		String propertyId = scanner.nextLine();
		
		System.out.print("Enter the new size: ");
		int newSize = scanner.nextInt();
		
		scanner.nextLine(); // Clear the buffer
			
		System.out.print("Enter the new type: ");
		String newType = scanner.nextLine();
		
		scanner.nextLine(); // Consume newline
		
		String sql = "UPDATE property SET size = ?, type = ? WHERE property_id = ?";
	     
		PreparedStatement stmt = conn.prepareStatement(sql);
		
		stmt.setInt(1, newSize);
		stmt.setString(2, newType);
		stmt.setString(3, propertyId);
		
		int rowsUpdated = stmt.executeUpdate();
		
		if (rowsUpdated > 0) {
			System.out.println("Property updated successfully.");
		} else {
			System.out.println("No property found with the specified ID.");
		}
	}
	
	public void updateCustomer(Connection conn) throws SQLException {
		
		// Define the variables
		int tennewStreetNum, ownnewStreetNum;
		String tentype, tennewName, tennewPatron, tennewSurName, tennewStreet, tenantemail, tenantphonenum, tennewCity, tennewPC, tenantId;
		String owntype, ownnewName, ownnewPatron, ownnewSurName, ownnewStreet, ownnewemail, ownnewphonenum, ownnewCity, ownnewPC, ownerId;
		String pastType = null;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Select the type of customer: 1) Individual or 2) Company: ");
		int a = scanner.nextInt();
		
		while ( a != 1 && a != 2 ) {
			System.out.println("Invalid input. Please choose one of the options on display: ");
			a = scanner.nextInt(); 
		}
		
		if ( a == 1 ) {
			
			System.out.println("Please enter the tenant information to update.");

			// Request and obtain tenant ID
			System.out.println("\nEnter the tenant ID: ");
			tenantId = scanner.next();
			
			// ---Get tenant past type value
			String pastTypeQuery = "SELECT type FROM tenant WHERE tenant_id = ?";
			
			PreparedStatement pastTypeStatement = conn.prepareStatement(pastTypeQuery);
			
			// Set parameter values for the owner update
			pastTypeStatement.setString(1, tenantId);
		
			ResultSet resultSet = pastTypeStatement.executeQuery();

			if (resultSet.next()) {
			    pastType = resultSet.getString("type");
			    // Retrieve the value of the "type" column from the result set
			    // and assign it to the "pastType" variable
			}

			// Close the result set and statement
			resultSet.close();
			pastTypeStatement.close();
			// ------------------------------------------
			
			System.out.println("What would you like to update?");
			System.out.println("1. Type  2. Name  3. Address  4. Email  5. Phone number: ");
			int input = scanner.nextInt();
			
			while ( input != 1 && input != 2 && input != 3 && input != 4 && input !=5 ) {
				System.out.println("Invalid input. Please choose one of the options on display: ");
				input = scanner.nextInt(); 
			}
			
			if ( input == 1 ) {
			
				System.out.print("\nEnter the new tenant type (Individual or Company): ");
			    do {
			    	tentype = scanner.next();
			        if (!tentype.equals("Individual") && !tentype.equals("Company")) {
			            System.out.println("Invalid input. Please enter again:");
			        }
			    } while(!tentype.equals("Individual") && !tentype.equals("Company"));
				
				String updateTenantQuery = "UPDATE tenant SET type = ? WHERE tenant_id = ?";
				
				PreparedStatement tenantStatement = conn.prepareStatement(updateTenantQuery);

				// Set parameter values for the tenant update
				tenantStatement.setString(1, tentype);
				tenantStatement.setString(2, tenantId);

				// Execute the tenant update query
				int rowsAffectedTenant = tenantStatement.executeUpdate();
				tenantStatement.close();
				
				if (rowsAffectedTenant > 0) {
		    		System.out.println("Tenant type update successful!");
		    	} else {
		    		System.out.println("Tenant type update failed!");
		    	}
				
				if (tentype.equals(pastType)) {
					
				} else if (tentype.equals("Company")) {
					System.out.println("Enter company name: ");
					String compName = scanner.next();
					
					String updateQuery = "UPDATE name SET firstname = NULL, patronymic = NULL, surname = NULL, companyname = ? "
						    				+ "WHERE name_id = (SELECT name_name_id FROM t_n WHERE tenant_tenant_id = ?)";
					
					PreparedStatement updateStatement = conn.prepareStatement(updateQuery);

					// Set parameter values for the owner update
					updateStatement.setString(1, compName);
					updateStatement.setString(2, tenantId);
					
					int rowsAffectedName = updateStatement.executeUpdate();
			        updateStatement.close();
			        
			        if (rowsAffectedName > 0) {
			            System.out.println("Tenant type update successful!");
			        } else {
			            System.out.println("Tenant type update failed!");
			        }
					
				} else {
					
					System.out.println("Enter first name: ");
					String fName = scanner.next();
					
					System.out.println("Enter patronymic: ");
					String patron = scanner.next();
					
					System.out.println("Enter surname: ");
					String lName = scanner.next();
					
					String updateQuery = "UPDATE name SET firstname = ?, patronymic = ?, surname = ?, companyname = NULL "
											+ "WHERE name_id = (SELECT name_name_id FROM t_n WHERE tenant_tenant_id = ?)";
					
					PreparedStatement update1Statement = conn.prepareStatement(updateQuery);

					// Set parameter values for the owner update
					update1Statement.setString(1, fName);
					update1Statement.setString(2, patron);
					update1Statement.setString(3, lName);
					update1Statement.setString(4, tenantId);
					
					int rowsAffectedName = update1Statement.executeUpdate();
			        update1Statement.close();
			        
			        if (rowsAffectedName > 0) {
			            System.out.println("Tenant type update successful!");
			        } else {
			            System.out.println("Tenant type update failed!");
			        }
				}	
				
			} else if ( input == 2 ) {
				
				if( pastType.equals("Individual") ) {
					System.out.println("\nEnter the new name: ");
					tennewName = scanner.next();
					
					System.out.println("\nEnter the new patronymic: ");
					tennewPatron = scanner.next();
					
					System.out.println("\nEnter the new surname: ");
					tennewSurName = scanner.next();
					
					String updateTNameQuery = "UPDATE name SET firstname = ?, patronymic = ?, surname = ? WHERE "
												+ "name_id = (SELECT name_name_id FROM t_n WHERE tenant_tenant_id = ?)";
					
					PreparedStatement tnameStatement = conn.prepareStatement(updateTNameQuery);

					// Set parameter values for the name update
					tnameStatement.setString(1, tennewName);
					tnameStatement.setString(2, tennewPatron);
					tnameStatement.setString(3, tennewSurName);
					tnameStatement.setString(4, tenantId);

					// Execute the name update query
					int rowsAffectedTName = tnameStatement.executeUpdate();
			    	tnameStatement.close();
			    	
			    	if (rowsAffectedTName > 0) {
			    		System.out.println("Tenant name update successful!");
			    	} else {
			    		System.out.println("Tenant name update failed!");
			    	}
			    	
				} else {
					System.out.println("\nEnter the new Company name: ");
					tennewName = scanner.next();
					
					String updateTNameQuery = "UPDATE name SET companyName = ? WHERE name_id = (SELECT name_name_id FROM t_n WHERE tenant_tenant_id = ?)";
					
					PreparedStatement tnameStatement = conn.prepareStatement(updateTNameQuery);

					// Set parameter values for the name update
					tnameStatement.setString(1, tennewName);
					tnameStatement.setString(2, tenantId);

					// Execute the name update query
					int rowsAffectedTName = tnameStatement.executeUpdate();
			    	tnameStatement.close();
			    	
			    	if (rowsAffectedTName > 0) {
			    		System.out.println("Tenant name update successful!");
			    	} else {
			    		System.out.println("Tenant name update failed!");
			    	}
				}
				
			} else if ( input == 3 ) {
				
				System.out.println("\nEnter the new street: ");
				tennewStreet = scanner.next();
				
				System.out.println("\nEnter the new street number: ");
				tennewStreetNum = scanner.nextInt();
				
				System.out.println("\nEnter the new city: ");
				tennewCity = scanner.next();
				
				System.out.println("\nEnter the new postal code: ");
				tennewPC = scanner.next();
				
				String updateTAddressQuery = "UPDATE address SET street = ?, street_num = ?, city = ?, `P.C_` = ? "
												+ "WHERE address_id = (SELECT address_address_id FROM t_a WHERE tenant_tenant_id = ?)";
		    	
		    	PreparedStatement taddressStatement = conn.prepareStatement(updateTAddressQuery);

		    	// Set parameter values for the address update
		    	taddressStatement.setString(1, tennewStreet);
		    	taddressStatement.setInt(2, tennewStreetNum);
		    	taddressStatement.setString(3, tennewCity);
		    	taddressStatement.setString(4, tennewPC);
		    	taddressStatement.setString(5, tenantId);

		    	// Execute the address update query
		    	int rowsAffectedTAddress = taddressStatement.executeUpdate();
		    	taddressStatement.close();
		    	
		    	if (rowsAffectedTAddress > 0) {
		    		System.out.println("Tenant address update successful!");
		    	} else {
		    		System.out.println("Tenant address update failed!");
		    	}
				
			} else if ( input == 4 ) {
				System.out.println("\nEnter new tenant email: ");
				tenantemail = scanner.next();
				
				String updateTEmailQuery = "UPDATE t_e SET email_email = ? WHERE tenant_tenant_id = ?";
				
				PreparedStatement temailStatement = conn.prepareStatement(updateTEmailQuery);

		    	// Set parameter values for the email update
		    	temailStatement.setString(1, tenantemail);
		    	temailStatement.setString(2, tenantId);

		    	// Execute the email update query
		    	int rowsAffectedTEmail = temailStatement.executeUpdate();
		    	temailStatement.close();
		    	
		    	if (rowsAffectedTEmail > 0) {
		    		System.out.println("Tenant email update successful!");
		    	} else {
		    		System.out.println("Tenant email update failed!");
		    	}
				
			} else {
				System.out.println("\nEnter new tenant phone number: ");
				tenantphonenum = scanner.next();
				
				String updateTPhoneQuery = "UPDATE t_p SET phonenumber_phone = ? WHERE tenant_tenant_id = ?";
		    	PreparedStatement tphoneStatement = conn.prepareStatement(updateTPhoneQuery);

		    	// Set parameter values for the phone update
		    	tphoneStatement.setString(1, tenantphonenum);
		    	tphoneStatement.setString(2, tenantId);

		    	// Execute the phone number update query
		    	int rowsAffectedTPhone = tphoneStatement.executeUpdate();
		    	tphoneStatement.close();
		    	
		    	if (rowsAffectedTPhone > 0) {
		    		System.out.println("Tenant phone update successful!");
		    	} else {
		    		System.out.println("Tenant phone update failed!");
		    	}
			}	
		} else {
			System.out.println("Please enter the owner information to update.");

			// Request and obtain owner ID
			System.out.print("\nEnter the owner ID: ");
			ownerId = scanner.next();
			
			// ---Get owner past type value
			
			String pastTypeQuery = "SELECT owner_type FROM owner WHERE owner_id = ?";
			PreparedStatement pastTypeStatement = conn.prepareStatement(pastTypeQuery);

			// Set parameter values for the owner update
			pastTypeStatement.setString(1, ownerId);
			
			ResultSet resultSet = pastTypeStatement.executeQuery();

			if (resultSet.next()) {
			    pastType = resultSet.getString("owner_type");
			    // Retrieve the value of the "owner_type" column from the result set
			    // and assign it to the "pastType" variable
			}

			// Close the result set and statement
			resultSet.close();
			pastTypeStatement.close();
			
			// ---------------------------------
			
			System.out.println("What would you like to update?\n");
			System.out.println("1. Type, 2. Name, 3. Address, 4. Email, 5. Phone number: ");
			int input = scanner.nextInt();
			
			while ( input != 1 && input != 2 && input != 3 && input != 4 && input !=5 ) {
				System.out.println("Invalid input. Please choose one of the options on display: ");
				input = scanner.nextInt(); 
			}
			
			if ( input == 1 ) {
				
				System.out.print("\nEnter the new owner type (Individual or Company): ");
			    do {
			    	owntype = scanner.next();
			        if (!owntype.equals("Individual") && !owntype.equals("Company")) {
			            System.out.println("Invalid input. Please enter again:");
			        }
			    } while(!owntype.equals("Individual") && !owntype.equals("Company"));
				
				String updateOwnerQuery = "UPDATE owner SET owner_type = ? WHERE owner_id = ?";
				
				PreparedStatement ownerStatement = conn.prepareStatement(updateOwnerQuery);

				// Set parameter values for the owner update
				ownerStatement.setString(1, owntype);
				ownerStatement.setString(2, ownerId);

				// Execute the owner update query
				int rowsAffectedOwner = ownerStatement.executeUpdate();
				ownerStatement.close();
				
				if (rowsAffectedOwner > 0) {
		    		System.out.println("Owner type update successful!");
		    	} else {
		    		System.out.println("Owner type update failed!");
		    	}
				
				if (owntype.equals(pastType)) {
				
				} else if (owntype.equals("Company")) {
					System.out.println("Enter company name: ");
					String compName = scanner.next();
					
					String updateQuery = "UPDATE name SET firstname = NULL, patronymic = NULL, surname = NULL, companyname = ? WHERE name_id = "
												+ "(SELECT name_name_id FROM o_n WHERE owner_owner_id = ?)";
					PreparedStatement updateStatement = conn.prepareStatement(updateQuery);

					// Set parameter values for the owner update
					updateStatement.setString(1, compName);
					updateStatement.setString(2, ownerId);
					
					// Execute the owner update query
					int rowsAffectedOwner1 = updateStatement.executeUpdate();
					updateStatement.close();
					
					if (rowsAffectedOwner1 > 0) {
			    		System.out.println("Owner company name update successful!");
			    	} else {
			    		System.out.println("Owner company name update failed!");
			    	}
					
				} else {
					
					System.out.println("Enter first name: ");
					String fName = scanner.next();
					
					System.out.println("Enter patronymic: ");
					String patron = scanner.next();
					
					System.out.println("Enter surname: ");
					String lName = scanner.next();
					
					String updateQuery = "UPDATE name SET firstname = ?, patronymic = ?, surname = ?, companyname = NULL WHERE name_id = "
												+ "(SELECT name_name_id FROM o_n WHERE owner_owner_id = ?)";
					PreparedStatement update1Statement = conn.prepareStatement(updateQuery);

					// Set parameter values for the owner update
					update1Statement.setString(1, fName);
					update1Statement.setString(2, patron);
					update1Statement.setString(3, lName);
					update1Statement.setString(4, ownerId);
					
					// Execute the owner update query
					int rowsAffectedOwner1 = update1Statement.executeUpdate();
					update1Statement.close();
					
					if (rowsAffectedOwner1 > 0) {
			    		System.out.println("Owner name update successful!");
			    	} else {
			    		System.out.println("Owner name update failed!");
			    	}
				}
				
			} else if ( input == 2 ) {

				if (pastType.equals("Company")) {
					System.out.print("\nEnter new company name: ");
					ownnewName = scanner.next();
					
					String updateONameQuery = "UPDATE name SET companyName = ? WHERE name_id = (SELECT name_name_id FROM o_n "
												+ "WHERE owner_owner_id = ?)";
					
					PreparedStatement onameStatement = conn.prepareStatement(updateONameQuery);

					// Set parameter values for the name update
					onameStatement.setString(1, ownnewName);
					onameStatement.setString(2, ownerId);

					// Execute the name update query
					int rowsAffectedOName = onameStatement.executeUpdate();
					onameStatement.close();
					
					if (rowsAffectedOName > 0) {
			    		System.out.println("Owner company name update successful!");
			    	} else {
			    		System.out.println("Owner company name update failed!");
			    	}
					
				}
				else {
					
					System.out.print("\nEnter owner first name: ");
					ownnewName = scanner.next();
					
					System.out.print("\nEnter owner patronymic: ");
					ownnewPatron = scanner.next();
					
					System.out.print("\nEnter owner surname: ");
					ownnewSurName = scanner.next();
					
					String updateONameQuery = "UPDATE name SET firstname = ?, patronymic = ?, surname = ? WHERE name_id = (SELECT name_name_id FROM o_n "
													+ "WHERE owner_owner_id = ?)";
					PreparedStatement onameStatement = conn.prepareStatement(updateONameQuery);

					// Set parameter values for the name update
					onameStatement.setString(1, ownnewName);
					onameStatement.setString(2, ownnewPatron);
					onameStatement.setString(3, ownnewSurName);
					onameStatement.setString(4, ownerId);

					// Execute the name update query
					int rowsAffectedOName = onameStatement.executeUpdate();
					onameStatement.close();
					
					if (rowsAffectedOName > 0) {
			    		System.out.println("Owner name update successful!");
			    	} else {
			    		System.out.println("Owner name update failed!");
			    	}			
				}
				
			} else if ( input == 3 ) {
				
				System.out.print("\nEnter the new Street: ");
				ownnewStreet = scanner.next();
				
				System.out.print("\nEnter the new Street number: ");
				ownnewStreetNum = scanner.nextInt();
				
				System.out.print("\nEnter the new city: ");
				ownnewCity = scanner.next();
				
				System.out.print("\nEnter the new postal code: ");
				ownnewPC = scanner.next();
				
				String updateOAddressQuery = "UPDATE address SET street = ?, street_num = ?, city = ?, `P.C_` = ? WHERE address_id = "
											+ "(SELECT address_address_id FROM o_a WHERE owner_owner_id = ?";
				
				PreparedStatement oaddressStatement = conn.prepareStatement(updateOAddressQuery);

				// Set parameter values for the address update
				oaddressStatement.setString(1, ownnewStreet);
				oaddressStatement.setInt(2, ownnewStreetNum);
				oaddressStatement.setString(3, ownnewCity);
				oaddressStatement.setString(4, ownnewPC);
				oaddressStatement.setString(5, ownerId);

				// Execute the address update query
				int rowsAffectedOAddress = oaddressStatement.executeUpdate();
				oaddressStatement.close();
				
				if (rowsAffectedOAddress > 0) {
		    		System.out.println("Owner address update successful!");
		    	} else {
		    		System.out.println("Owner address update failed!");
		    	}
				
			} else if ( input == 4 ) {
				
				System.out.print("\nEnter the new email: ");
				ownnewemail = scanner.next();
				
				String updateOEmailQuery = "UPDATE o_e SET email_email = ? WHERE owner_owner_id = ?";
				
				PreparedStatement oemailStatement = conn.prepareStatement(updateOEmailQuery);

				// Set parameter values for the email update
				oemailStatement.setString(1, ownnewemail);
				oemailStatement.setString(2, ownerId);

				// Execute the email update query
				int rowsAffectedOEmail = oemailStatement.executeUpdate();
				oemailStatement.close();
				
				if (rowsAffectedOEmail > 0) {
		    		System.out.println("Owner email update successful!");
		    	} else {
		    		System.out.println("Owner email update failed!");
		    	}
				
			} else if ( input == 5 ) {
				System.out.print("\nEnter new phone number: ");
				ownnewphonenum = scanner.next();
				
				String updateOPhoneQuery = "UPDATE o_p SET phonenumber_phone = ? WHERE owner_owner_id = ?";
				PreparedStatement ophoneStatement = conn.prepareStatement(updateOPhoneQuery);

				// Set parameter values for the phone update
				ophoneStatement.setString(1, ownnewphonenum);
				ophoneStatement.setString(2, ownerId);

				// Execute the phone number update query
				int rowsAffectedOPhone = ophoneStatement.executeUpdate();
				ophoneStatement.close();
				
				if (rowsAffectedOPhone > 0) {
		    		System.out.println("Owner phone number update successful!");
		    	} else {
		    		System.out.println("Owner phone number failed!");
		    	}
			}
		}
	}

	public void updateRentalProperty(Connection conn) throws SQLException {
		// Define the variables
		String newSize, newType, rentalpropertyId, tenantId, branchId, employeeId, addate, rentaladId;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("\nEnter the ID of the rental property you'd like to update: ");
		rentalpropertyId = scanner.next();
		
	    System.out.println("What would you like to update?");
	    System.out.println("\n1. Size  2. Tenant 3. Branch  4. Employee 5. Ad Date  6. Type: "); 
	    int input = scanner.nextInt();
	    
	    while ( input != 1 && input != 2 && input != 3 && input != 4 && input != 5 && input != 6 ) {
			System.out.println("Invalid input. Please choose one of the options on display: ");
			input = scanner.nextInt(); 
		}
	    
	    if ( input == 1 ) { 
	    	System.out.print("\nEnter the rental property's new size: ");
	    	newSize = scanner.next();
	    	
	    	String updatePropertySizeQuery = "UPDATE property SET size = ? WHERE property_id = ?";
	    	
	    	// Create prepared statement
	    	PreparedStatement sizestatement = conn.prepareStatement(updatePropertySizeQuery);
	    	
	    	// Set parameter values for the prepared statement
	    	sizestatement.setString(1, newSize);
	    	sizestatement.setString(2, rentalpropertyId);
	    	
	    	// Execute the query
	    	int rowsAffectedSize = sizestatement.executeUpdate();
	    	
	    	if (rowsAffectedSize > 0) {
	    		System.out.println("Rental property size update successful!");
	    	} else {
	    		System.out.println("Rental property size update failed!");
	    	}
	     
	    	// Close the statement
	    	sizestatement.close();
	    	
	    } else if ( input == 2 ) {
	    	
	    	System.out.print("\nEnter the new tenant's id: ");
	    	tenantId = scanner.next();
				
	    	String updateTenantQuery = "UPDATE property SET tenant_tenant_id = ? WHERE property_id = ?";
	     
	    	// Create prepared statement
	    	PreparedStatement tstatement = conn.prepareStatement(updateTenantQuery);
	              
	    	// Set parameter values for the prepared statement
	    	tstatement.setString(1, tenantId);
	    	tstatement.setString(2, rentalpropertyId);
	    	
	    	// Execute the query
	    	int rowsAffectedTen = tstatement.executeUpdate();
	    	
	    	if (rowsAffectedTen > 0) {
	    		System.out.println("Rental property update successful!");
	    	} else {
	    		System.out.println("Rental property update failed!");
	    	}
	     
	    	// Close the statement
	    	tstatement.close();
				
	    } else if ( input == 3 ) {
	    	
	    	System.out.print("\nEnter the rental property's new branch: ");
	    	branchId = scanner.next();
	    	
	    	String updateBranchQuery = "UPDATE property SET branch_branch_id = ? WHERE property_id = ?";
	    	
	    	// Create prepared statement
	    	PreparedStatement bstatement = conn.prepareStatement(updateBranchQuery);
	    	
	    	// Set parameter values for the prepared statement
	    	bstatement.setString(1, branchId);
	    	bstatement.setString(2, rentalpropertyId);
	    	
	    	// Execute the query
	    	int rowsAffectedB = bstatement.executeUpdate();
	    	
	    	if (rowsAffectedB > 0) {
	    		System.out.println("Rental property update successful!");
	    	} else {
	    		System.out.println("Rental property update failed!");
	    	}
	     
	    	// Close the statement
	    	bstatement.close();
	
	    } else if ( input == 4 ) {
	    	System.out.print("\nEnter the new employee: ");
	    	employeeId = scanner.next();
				 	 
	    	String updateEmployeeQuery = "UPDATE property SET emplo_employee_id = ? WHERE property_id = ?";
	     
	    	// Create prepared statement
	    	PreparedStatement emstatement = conn.prepareStatement(updateEmployeeQuery);
	    	
	    	// Set parameter values for the prepared statement
	    	emstatement.setString(1, employeeId);
	    	emstatement.setString(2, rentalpropertyId);
	    	
	    	// Execute the query
	    	int rowsAffectedEm = emstatement.executeUpdate();
	     
	    	if (rowsAffectedEm > 0) {
	    		System.out.println("Rental property update successful!");
	    	} else {
	    		System.out.println("Rental property update failed!");
	    	}
	     
	    	// Close the statement
	    	emstatement.close();
				
	    } else if ( input == 5 ) {
	    	System.out.print("\nEnter the rental property's new ad date (yyyy-MM-dd): ");
	    	addate = scanner.next();
					
	    	String updateAddateQuery = "UPDATE rental_ad SET ad_date = ? WHERE property_property_id = ?";
	     
	    	// Create prepared statement
	    	PreparedStatement adstatement = conn.prepareStatement(updateAddateQuery);
	    	
	    	// Set parameter values for the prepared statement
	    	adstatement.setString(1, addate);
	    	adstatement.setString(2, rentalpropertyId);
	    	
	    	// Execute the query
	    	int rowsAffectedAD = adstatement.executeUpdate();
	    	
	    	if (rowsAffectedAD > 0) {
	    		System.out.println("Rental property update successful!");
	    	} else {
	    		System.out.println("Rental property update failed!");
	    	}
	     
	    	// Close the statement
	    	adstatement.close();
	    	
	    } else if ( input == 6 ) {
	    	    	
	    	// Request and obtain new property type with validation
			System.out.print("Enter new property type (Acceptable Property Types: \"Agricultural\", "
							+ "\"Commercial\", \"Industrial\", \"Residential\", \"Special Purpose\"): ");
		    do {
		    	newType = scanner.nextLine();
		        if (!newType.equals("Agricultural") && !newType.equals("Commercial") && !newType.equals("Industrial") 
		        	&& !newType.equals("Residential") && !newType.equals("Special Purpose") ) {
		        	
		        	System.out.println("Invalid input. Please enter again:");
		        }
		    } while (!newType.equals("Agricultural") && !newType.equals("Commercial") && !newType.equals("Industrial") 
		    		&& !newType.equals("Residential") && !newType.equals("Special Purpose"));
				
				
		    String updateTypeQuery = "UPDATE property SET type = ? WHERE property_id = ?";
		    
		    // Create prepared statement
		    PreparedStatement tystatement = conn.prepareStatement(updateTypeQuery);
		    
		    // Set parameter values for the prepared statement
		    tystatement.setString(1, newType);
		    tystatement.setString(2, rentalpropertyId);
	     
		    // Execute the query
		    int rowsAffectedType = tystatement.executeUpdate();
		    
		    if (rowsAffectedType > 0) {
		    	System.out.println("Rental property update successful!");
		    } else {
		    	System.out.println("Rental property update failed!");
		    }
	     
		    // Close the statement
		    tystatement.close();		
	    }
	}

	public void showRentalProperties(Connection conn) throws SQLException {
        System.out.println("You chose to view all rental properties\n");

        String rentalPropQuery = "SELECT p.property_id, p.Size, p.type, p.tenant_tenant_id, " +
                                 "p.branch_branch_id " +
                                 "FROM property p " +
                                 "JOIN branch b ON p.branch_branch_id = b.branch_id " +
                                 "ORDER BY b.branch_id";

        Statement rentalPropStatement = conn.createStatement();
        ResultSet rentalPropSet = rentalPropStatement.executeQuery(rentalPropQuery);

        while (rentalPropSet.next()) {
            String propertyId = rentalPropSet.getString("property_id");
            String propSize = rentalPropSet.getString("Size");
            String propType = rentalPropSet.getString("type");
            String propTenant = rentalPropSet.getString("tenant_tenant_id");
            String propBranch = rentalPropSet.getString("branch_branch_id");


            System.out.println("Property ID: " + propertyId);
            System.out.println("Property Type: " + propType);
            System.out.println("Property Size: " + propSize);
            System.out.println("Tenant: " + propTenant);
            System.out.println("Branch: " + propBranch);

            System.out.println("----------------------");
        }

        rentalPropStatement.close();
        rentalPropSet.close();
    }

	
	public void showRentedProperties(Connection conn) throws SQLException {
	    // Create an ArrayList to store the retrieved values
	    ArrayList<String> rentedProperties = new ArrayList<>();

	    // Prepare the SQL statement with placeholders for the search parameters
	    String rentedpropertyQuery = "SELECT property_id FROM property WHERE tenant_tenant_id IS NOT NULL";

	    // Create a PreparedStatement object
	    PreparedStatement rentedstatement = conn.prepareStatement(rentedpropertyQuery);

	    // Execute the query
	    ResultSet resultSet = rentedstatement.executeQuery();

	    // Process the result set
	    while (resultSet.next()) {
	        String value = resultSet.getString("property_id");
	        rentedProperties.add(value);
	    }

	    // Close the result set, statement, and connection
	    resultSet.close();
	    rentedstatement.close();
	    conn.close();

	    // Display the retrieved rented properties
	    System.out.println("Rented Properties:");
	    for (String property : rentedProperties) {
	        System.out.println(property);
	    }
	}
	

	public void showAvailableProperties(Connection conn) throws SQLException {

	    // Create an ArrayList to store the retrieved values
	    ArrayList<String> availableProperties = new ArrayList<>();

	    // Prepare the SQL statement with placeholders for the search parameters
	    String availablePropertyQuery = "SELECT DISTINCT p.property_id, p.size, p.type " +
	    								"FROM property p " +
	    								"WHERE p.property_id IN (SELECT ra.property_property_id FROM rental_ad ra) " +
	    								"AND p.tenant_tenant_id IS NULL";
	    
	    // Create a PreparedStatement object
	    PreparedStatement avStatement = conn.prepareStatement(availablePropertyQuery);

	    // Execute the query
	    ResultSet resultSet = avStatement.executeQuery();

	    // Process the result set
	    while (resultSet.next()) {
	        String propertyId = resultSet.getString("property_id");
	        String propertySize = resultSet.getString("size");
	        String propertyType = resultSet.getString("type");

	        // Store the property information in the ArrayList
	        String propertyInfo = "Property ID: " + propertyId + ", Size: " + propertySize + ", Type: " + propertyType ;
	        availableProperties.add(propertyInfo);
	    }

	    // Close the result set, statement, and connection
	    resultSet.close();
	    avStatement.close();
	    conn.close();

	    // Print the available properties
	    System.out.println("Available Properties (No Tenant Assigned):");
	    for (String property : availableProperties) {
	        System.out.println(property);
	    }
	}
	
	
	public void createLeaseContract(Connection conn) throws SQLException {
		String leaseId;
		Scanner scanner = new Scanner(System.in);
		System.out.print("\n~~~~~~\n");
        
        System.out.print("\nEnter property Id of a property that already exists and does not have a tenant:");
        String propertyId = scanner.next();
        String query = "SELECT tenant_tenant_id FROM property WHERE property_id = ? AND tenant_tenant_id IS NOT NULL";
        scanner.nextLine(); // Consume the newline character
        PreparedStatement statement = conn.prepareStatement(query);
        statement.setString(1, propertyId);
        ResultSet resultSet = statement.executeQuery();

        // Check if a tenant ID exists for the property
        boolean isRented = resultSet.next();
        if (isRented) {
            System.out.println("The property with ID " + propertyId + " is currently rented.");
        }
        else {
        	System.out.print("Enter lease Id:");
            leaseId = scanner.next();
        System.out.print("\nEnter sign date (yyyy-MM-dd):");
        String signnDate = scanner.nextLine();

        System.out.print("\nEnter start date (yyyy-MM-dd):");
        String startDate = scanner.nextLine();

        System.out.print("\nEnter end date (yyyy-MM-dd):");
        String endDate = scanner.nextLine();
        
        System.out.print("\nEnter tenant Id that already is inserted:");
        String tenantId = scanner.next();

        String enterLeaseQuery= "INSERT INTO lease (lease_id, sign_date, start_date, end_date, property_property_id, "
        							+ "tenant_tenant_id) VALUES (?, ?, ?, ?, ?, ?)";
        
        PreparedStatement leaseStatement = conn.prepareStatement(enterLeaseQuery);
        
        leaseStatement.setString(1, leaseId);
        leaseStatement.setString(2,signnDate);
        leaseStatement.setString(3, startDate);
        leaseStatement.setString(4, endDate);
        leaseStatement.setString(5, propertyId);
        leaseStatement.setString(6, tenantId);
        
        int affRowsLease= leaseStatement.executeUpdate();
        if (affRowsLease > 0) {
            System.out.println("Lease details insert successful!");
        } else {
            System.out.println("Lease details insert failed!");
        }

        // Close the statement
        leaseStatement.close();
        }
	}
	
	

	public void deleteProperty(Connection conn) throws SQLException {
		// Request and obtain property ID and start loop
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please enter the property ID to delete.");
		int propertyId = scanner.nextInt();
	     
		String deletePropertyQuery = "DELETE FROM property WHERE property_id = ?";
		
		// Create prepared statement
		PreparedStatement statement = conn.prepareStatement(deletePropertyQuery);
		
		// Set parameter value for the prepared statement
		statement.setInt(1, propertyId);
		
		// Execute the query
	    int rowsDeleted = statement.executeUpdate();
	     
	    if (rowsDeleted > 0) {
	    	System.out.println("Property deletion successful!");
	    } else {
	    	System.out.println("Property deletion failed!");
	    }
	     
	    // Close the statement
	    statement.close();
	}

 	
	public void showViewedTenants(Connection conn) throws SQLException {
 	 
		// Create an ArrayList to store the retrieved values
		ArrayList<String> viewingTenants = new ArrayList<>();
		
		// Prepare the SQL statement with placeholders for the search parameters
		String viewTenants = "SELECT DISTINCT tenant_tenant_id FROM lease GROUP BY view_date HAVING COUNT(*) > 1";

		// Create a PreparedStatement object
		PreparedStatement vstatement = conn.prepareStatement(viewTenants);
 		 
		// Execute the query
		ResultSet resultSet = vstatement.executeQuery();

		// Process the result set
		while (resultSet.next()) {
			String value = resultSet.getString("tenant_tenant_id");
			viewingTenants.add(value);
		}
 	     
		// Close the result set, statement, and connection
		resultSet.close();
		vstatement.close();
		conn.close(); 
		
		// Print the retrieved tenant IDs
	    System.out.println("Viewed Tenants:");
	    for (String tenantID : viewingTenants) {
	        System.out.println(tenantID);
	    }
 	}
 	
 	public void showNewspaperProperties(Connection conn) throws SQLException {
 	 
 	     // Create an ArrayList to store the retrieved values
 	     ArrayList<String> newsProperties = new ArrayList<>();

 	     // Prepare the SQL statement with placeholders for the search parameters
 	     String newsproperty = "SELECT name FROM newspaper WHERE rental_ad_rental_ad_id = (SELECT rental_ad_id FROM rental_ad "
 	     				+ "WHERE property_property_id = (SELECT property_id FROM property WHERE tenant_tenant_id IS NULL))";
 	     
 	     // Create a PreparedStatement object
 	     PreparedStatement newsstatement = conn.prepareStatement(newsproperty);
 		 
 	     // Execute the query
 	     ResultSet resultSet = newsstatement.executeQuery();

 	     // Process the result set
 	     while (resultSet.next()) {
 	    	 String value = resultSet.getString("name");
 	    	 newsProperties.add(value);
 	     }

 	     // Close the result set, statement, and connection
 	     resultSet.close();
 	     newsstatement.close();
 	     conn.close();
 	     
 	     // Display the retrieved newspaper names
 	     System.out.println("Newspaper Names:");
 	     for (String property : newsProperties) {
 	    	 System.out.println(property);
 	     }
 	}

 	public void updateInfo(Connection conn) throws SQLException {
 		 
 	    // Define the variables
 	    String ten_email, em_email, ten_phone_num, em_phone_num, ten_street, em_street, ten_city, em_city, ten_postal_code, em_postal_code;
 	    String tenantId, employeeId;
 		int ten_street_num, em_street_num, input, answer;
 		
 		Scanner scanner = new Scanner(System.in);
 		
 		System.out.print("\nWould you like to update the info of: 1) tenant or 2) branch employee: ");
 	    int i = scanner.nextInt();
 		while ( i != 1 && i != 2 ) {
 		   System.out.println("Invalid input. Please choose one of the options on display: ");
 		}
 		
 		if ( i == 1 ) {
 			do {
 				System.out.print("\nEnter tenant ID");
 				tenantId = scanner.next();
 		
 				System.out.println("What would you like to update?");
 				System.out.println("1. Email  2. Phone Number  3. Street  4. Street Number 5. City  6. Postal Code: "); 
 				input = scanner.nextInt();
 				
 				while ( input != 1 && input != 2 && input != 3 && input != 4 && input != 5 ) {
 		 		   System.out.println("Invalid input. Please choose one of the options on display: ");
 		 		}
 				
 				if ( input == 1 ) { 
 			     System.out.print("\nEnter the tenant's new email: ");
 		         ten_email = scanner.next();
 				 
 				 String updateTEmailQuery = "UPDATE t_e SET email_email = ? WHERE tenant_tenant_id = ?";
 	     
 	             // Create prepared statement
 	              PreparedStatement temailstatement = conn.prepareStatement(updateTEmailQuery);
 	     
 	             // Set parameter values for the prepared statement
 	             temailstatement.setString(1, ten_email);
 	             temailstatement.setString(2, tenantId);
 	     
 	             // Execute the query
 	             int rowsAffectedTEmail = temailstatement.executeUpdate();
 	     
 	             if (rowsAffectedTEmail > 0) {
 	             System.out.println("Tenant email update successful!");
 	             } else {
 	             System.out.println("Tenant email update failed!");
 	             }
 	     
 	             // Close the statement
 	             temailstatement.close();
 			    }
 			
 			  if ( input == 2 ) { 
 			     System.out.print("\nEnter the tenant's new phone number: ");
 		         ten_phone_num = scanner.next();
 				 
 				 String updateTPhoneQuery = "UPDATE t_p SET phonenumber_phone = ? WHERE tenant_tenant_id = ?";
 	     
 	             // Create prepared statement
 	              PreparedStatement tphonestatement = conn.prepareStatement(updateTPhoneQuery);
 	     
 	             // Set parameter values for the prepared statement
 	             tphonestatement.setString(1, ten_phone_num);
 	             tphonestatement.setString(2, tenantId);
 	     
 	             // Execute the query
 	             int rowsAffectedTPhone = tphonestatement.executeUpdate();
 	     
 	             if (rowsAffectedTPhone > 0) {
 	             System.out.println("Tenant phone update successful!");
 	             } else {
 	             System.out.println("Tenant phone update failed!");
 	             }
 	     
 	             // Close the statement
 	             tphonestatement.close();
 	             }
 		
 		      if ( input == 3 ) {
 		    	 
 		    	  System.out.print("\nEnter the tenant's new street: ");
 		         ten_street = scanner.next();
 				 
 				 String updateTStreetQuery = "UPDATE address SET street = ? WHERE address_id = (SELECT address_address_id FROM t_a "
 				 								+ "WHERE tenant_tenant_id = ?)";
 	     
 	             // Create prepared statement
 	              PreparedStatement tstreetstatement = conn.prepareStatement(updateTStreetQuery);
 	     
 	             // Set parameter values for the prepared statement
 	             tstreetstatement.setString(1, ten_street);
 	             tstreetstatement.setString(2, tenantId);
 	     
 	             // Execute the query
 	             int rowsAffectedTStreet = tstreetstatement.executeUpdate();
 	     
 	             if (rowsAffectedTStreet > 0) {
 	            	 System.out.println("Tenant street update successful!");
 	             } else {
 	            	 System.out.println("Tenant street update failed!");
 	             }
 	     
 	             // Close the statement
 	             tstreetstatement.close();
 		      }
 		      if ( input == 4 ) { 
 				 
 			     System.out.print("\nEnter the tenant's new street number: ");
 		         ten_street_num = scanner.nextInt();
 				 
 				 String updateTStreetNumQuery = "UPDATE address SET street_num = ? WHERE address_id = (SELECT address_address_id "
 				 											+ "FROM t_a WHERE tenant_tenant_id = ?)"; 	     
 	             
 				 // Create prepared statement
 	              PreparedStatement tstreetnumstatement = conn.prepareStatement(updateTStreetNumQuery);
 	     
 	             // Set parameter values for the prepared statement
 	             tstreetnumstatement.setInt(1, ten_street_num);
 	             tstreetnumstatement.setString(2, tenantId);
 	     
 	             // Execute the query
 	             int rowsAffectedTStreetNum = tstreetnumstatement.executeUpdate();
 	     
 	             if (rowsAffectedTStreetNum > 0) {
 	            	 System.out.println("Tenant street number update successful!");
 	             } else {
 	            	 System.out.println("Tenant street number update failed!");
 	             }
 	     
 	             // Close the statement
 	             tstreetnumstatement.close();
 				 }
 				 
 			  if ( input == 5 ) {
 				 
 			     System.out.print("\nEnter the tenant's new city: ");
 		         ten_city = scanner.next();
 				 
 				 String updateTCityQuery = "UPDATE address SET city = ? WHERE address_id = (SELECT address_address_id FROM t_a "
 				 								+ "WHERE tenant_tenant_id = ?)";
 	     
 	             // Create prepared statement
 	              PreparedStatement tcitystatement = conn.prepareStatement(updateTCityQuery);
 	     
 	             // Set parameter values for the prepared statement
 	             tcitystatement.setString(1, ten_city);
 	             tcitystatement.setString(2, tenantId);
 	     
 	             // Execute the query
 	             int rowsAffectedTCity = tcitystatement.executeUpdate();
 	     
 	             if (rowsAffectedTCity > 0) {
 	             System.out.println("Tenant city update successful!");
 	             } else {
 	             System.out.println("Tenant city update failed!");
 	             }
 	     
 	             // Close the statement
 	             tcitystatement.close();
 				 }
 				 
 			if ( input == 6 ) {
 				 
 			     System.out.print("\nEnter the tenant's new postal code: ");
 		         ten_postal_code = scanner.next();
 				 
 				 String updateTPCQuery = "UPDATE address SET `P.C_` = ? WHERE address_id = (SELECT address_address_id FROM t_a "
 				 								+ "WHERE tenant_tenant_id = ?)";
 	     
 	             // Create prepared statement
 	              PreparedStatement tpcstatement = conn.prepareStatement(updateTPCQuery);
 	     
 	             // Set parameter values for the prepared statement
 	             tpcstatement.setString(1, ten_postal_code);
 	             tpcstatement.setString(2, tenantId);
 	     
 	             // Execute the query
 	             int rowsAffectedTPC = tpcstatement.executeUpdate();
 	     
 	             if (rowsAffectedTPC > 0) {
 	            	 System.out.println("Tenant postal code update successful!");
 	             } else {
 	            	 System.out.println("Tenant postal code update failed!");
 	             }
 	     
 	             // Close the statement
 	             tpcstatement.close();
 			}
 				 
 			System.out.println("Would you like to update something else? Press 1 for Yes: ");
 			answer = scanner.nextInt();
 			
 			} while( answer == 1 ); 
 				 
 		} else {
 			
 			do {
 				System.out.print("\nEnter employee ID");
 				employeeId = scanner.next();
 		
 				System.out.println("What would you like to update?");
 				System.out.println("\n1. Email  2. Phone Number  3. Street  4. Street Number 5. City  6. Postal Code: "); 
 				input = scanner.nextInt();
 				
 				while ( input != 1 && input != 2 && input != 3 && input != 4 && input != 5 && input != 6 ) {
  		 		   System.out.println("Invalid input. Please choose one of the options on display: ");
  		 		}
 				
 				if ( input == 1 ) {
 					System.out.print("\nEnter the employee's new email: ");
 					em_email = scanner.next();
 				 
 					String updateEEmailQuery = "UPDATE e_e SET email_email = ? WHERE emplo_employee_id = ?";
 	     
 					// Create prepared statement
 					PreparedStatement eemailstatement = conn.prepareStatement(updateEEmailQuery);
 	     
 					// Set parameter values for the prepared statement
 					eemailstatement.setString(1, em_email);
 					eemailstatement.setString(2, employeeId);
 	     
 					// Execute the query
 					int rowsAffectedEEmail = eemailstatement.executeUpdate();
 	     
 					if (rowsAffectedEEmail > 0) {
 						System.out.println("Employee email update successful!");
 					} else {
 						System.out.println("employee email update failed!");
 					}
 	     
 					// Close the statement
 					eemailstatement.close();
 				}
 			
 				else if ( input == 2 ) { 
 					System.out.print("\nEnter the employee's new phone number: ");
 					em_phone_num = scanner.next();
 				 
 					String updateEPhoneQuery = "UPDATE e_p SET phonenumber_phone = ? WHERE emplo_employee_id = ?";
 	     
 					// Create prepared statement
 					PreparedStatement ephonestatement = conn.prepareStatement(updateEPhoneQuery);
 	     
 					// Set parameter values for the prepared statement
 					ephonestatement.setString(1, em_phone_num);
 					ephonestatement.setString(2, employeeId);
 	     
 					// Execute the query
 					int rowsAffectedEPhone = ephonestatement.executeUpdate();
 	     
 					if (rowsAffectedEPhone > 0) {
 						System.out.println("Employee phone update successful!");
 					} else {
 						System.out.println("Employee phone update failed!");
 					}
 	     
 					// Close the statement
 					ephonestatement.close();
 				}
 		
 				else if ( input == 3 ) { 
 				 
 					System.out.print("\nEnter the employee's new street: ");
 					ten_street = scanner.next();
 				 
 					String updateEStreetQuery = "UPDATE address SET street = ? WHERE address_id = (SELECT address_address_id FROM e_a "
 											+ "WHERE emplo_employee_id = ?)";
 	     
 					// Create prepared statement
 					PreparedStatement estreetstatement = conn.prepareStatement(updateEStreetQuery);
 	     
 					// Set parameter values for the prepared statement
 					estreetstatement.setString(1, ten_street);
 					estreetstatement.setString(2, employeeId);
 	     
 					// Execute the query
 					int rowsAffectedEStreet = estreetstatement.executeUpdate();
 	     
 					if (rowsAffectedEStreet > 0) {
 						System.out.println("Employee street update successful!");
 					} else {
 						System.out.println("Employee street update failed!");
 					}
 	     
 					// Close the statement
 					estreetstatement.close();
 				}
 		
 				else if ( input == 4 ) { 
 				 
 					System.out.print("\nEnter the employee's new street number: ");
 					em_street_num = scanner.nextInt();
 				 
 					String updateEStreetNumQuery = "UPDATE address SET street_num = ? WHERE address_id = (SELECT address_address_id FROM e_a "
 													+ "WHERE emplo_employee_id = ?)";
 	     
 					// Create prepared statement
 					PreparedStatement estreetnumstatement = conn.prepareStatement(updateEStreetNumQuery);
 	     
 					// Set parameter values for the prepared statement
 					estreetnumstatement.setInt(1, em_street_num);
 					estreetnumstatement.setString(2, employeeId);
 	     
 					// Execute the query
 					int rowsAffectedEStreetNum = estreetnumstatement.executeUpdate();
 	     
 					if (rowsAffectedEStreetNum > 0) {
 						System.out.println("Employee street number update successful!");
 					} else {
 						System.out.println("Employee street number update failed!");
 					}
 	     
 					// Close the statement
 					estreetnumstatement.close();
 				}
 				 
 				else if ( input == 5 ) { 
 				 
 					System.out.print("\nEnter the employee's new city: ");
 					em_city = scanner.next();
 				 
 					String updateECityQuery = "UPDATE address SET city = ? WHERE address_id = (SELECT address_address_id FROM e_a "
 												+ "WHERE emplo_employee_id)";
 	     
 					// Create prepared statement
 					PreparedStatement ecitystatement = conn.prepareStatement(updateECityQuery);
 	     
 					// Set parameter values for the prepared statement
 					ecitystatement.setString(1, em_city);
 					ecitystatement.setString(2, employeeId);
 	     
 					// Execute the query
 					int rowsAffectedECity = ecitystatement.executeUpdate();
 	     
 					if (rowsAffectedECity > 0) {
 						System.out.println("Employee city update successful!");
 					} else {
 						System.out.println("Employee city update failed!");
 					}
 	     
 					// Close the statement
 					ecitystatement.close();
 				}
 				 
 				else if ( input == 6 ) {
 				 
 					System.out.print("\nEnter the employee's new postal code: ");
 					em_postal_code = scanner.next();
 				 
 					String updateEPCQuery = "UPDATE address SET `P.C_` = ? WHERE address_id = (SELECT address_address_id FROM e_a "
 											+ "WHERE emplo_employee_id = ?)";
 	     
 					// Create prepared statement
 					PreparedStatement epcstatement = conn.prepareStatement(updateEPCQuery);
 	     
 					// Set parameter values for the prepared statement
 					epcstatement.setString(1, em_postal_code);
 					epcstatement.setString(2, employeeId);
 	     
 					// Execute the query
 					int rowsAffectedEPC = epcstatement.executeUpdate();
 	     
 					if (rowsAffectedEPC > 0) {
 						System.out.println("Employee postal code update successful!");
 					} else {
 						System.out.println("Employee postal code update failed!");
 					}
 	     
 					// Close the statement
 					epcstatement.close();
 				}
 				
 				System.out.println("Would you like to update something else? Press 1 for Yes: ");
 				answer = scanner.nextInt();
 				
 			} while ( answer == 1 ); 
 		}
 	}
 
	
 	public static void main(String[] args) throws SQLException {
		// Initialize variables
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "yo";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root"; 
		String password = "";
		String input;
		
		MysqlConnect app = new MysqlConnect();
		Scanner sc = new Scanner(System.in);
		
		// Load the MySQL driver and establish a connection
		try{
			Class.forName(driver).getDeclaredConstructor().newInstance();
			conn = DriverManager.getConnection(url+dbName, userName, password);
			System.out.println("Connected to database");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		do {
			// Request user to choose an option
			System.out.println( "Insert a: (1a) Property, (1b) Customer, (1c) Rental property\n"
					+ "Update: (2a) a Property, (2b) an already existing Customer, (2c) a Rental property\n"
					+ "Show the list with: (3a) Rental properties, (3b) Already Rented properties, (3c) Available Properties\n"
					+ "(4a) Create a Lease contract\n(5a) Delete a Property that is not available\n"
					+ "(6a) Show the Tenants that have viewed Properties more than once\n"
					+ "(7a) Update info (7b) Show Newspaper Properties \n"
					+ "(0) Exit\n"
					+ "Please choose one of the given options:");
			
			sc = new Scanner(System.in);
			
			input = sc.nextLine();
				
			switch (input) {
				case "1a":
            		app.insertProperty(conn);
            		break;
            	case "1b":
            		app.insertCustomer(conn);
            		break;
            	case "1c":
            		app.insertRentalProperty(conn);
            		break;
            	case "2a":
            		app.updateProperty(conn);
            		break;
            	case "2b":
            		app.updateCustomer(conn);
            		break;
            	case "2c":
            		app.updateRentalProperty(conn);
            		break;
            	case "3a":
            		app.showRentalProperties(conn);
            		break;
            	case "3b":
            		app.showRentedProperties(conn);
            		break;
            	case "3c":
            		app.showAvailableProperties(conn);
            		break;
            	case "4a":
            		app.createLeaseContract(conn);
            		break;
            	case "5a":
            		app.deleteProperty(conn);
            		break;
            	case "6a":
            		app.showViewedTenants(conn);
            		break;
            	case "7a":
            		app.updateInfo(conn);
            		break;
            	case "7b":
            		app.showNewspaperProperties(conn);
            		break;
            	case "0":
            		break;
            	default:
            		System.out.println("Invalid option");
             	break;
			}
 
	    } while (!input.equals("0"));
		
		// This will ensure that the Scanner is properly closed
     sc.close();
     
     // Disconnect from database
     try {
         if (conn != null)
             conn.close();
     } catch (SQLException e) {
         e.printStackTrace();
     }
     System.out.println("Disconnected from database");
	
	}
}